import {
  Controller,
  Post,
  UseInterceptors,
  UploadedFile,
  HttpStatus,
  HttpException,
  HttpCode,
  Body,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { TranslationsService } from './translations.service';

type Response = {
  statusCode: HttpStatus;
  message: string;
  data: any;
};
@Controller('api/v1')
export class TranslationsController {
  constructor(private readonly translationsService: TranslationsService) {}

  @Post('insert')
  @UseInterceptors(FileInterceptor('file'))
  async uploadFile(@UploadedFile() file): Promise<Response> {
    try {
      const data = await this.translationsService.processFile(file.buffer);

      return {
        statusCode: HttpStatus.OK,
        message: 'Data inserted successfully',
        data: data,
      };
    } catch (error) {
      throw new HttpException(
        'Internal server error',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Post('search')
  @HttpCode(HttpStatus.OK)
  async search(@Body() body: { field: string; searchText: any }) {
    try {
      const { field, searchText } = body;
      const response = await this.translationsService.searchText({
        field,
        searchText,
      });
      return response;
    } catch (error) {
      throw new HttpException(
        'Internal server error',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
