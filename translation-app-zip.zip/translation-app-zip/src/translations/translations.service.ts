import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import * as XLSX from 'xlsx';
import axios from 'axios';
import { ConfigService } from '@nestjs/config';

interface Translation {
  english: string;
  chinese: string;
}

@Injectable()
export class TranslationsService {
  private readonly AZURE_EMBEDDING_API_URL: string;
  private readonly AZURE_EMBEDDING_API_KEY: string;
  private readonly elasticSearchApiURL: string;
  private readonly elasticSearchApiKey: string;

  constructor(private readonly configService: ConfigService) {
    this.AZURE_EMBEDDING_API_URL = this.configService.get<string>(
      'AZURE_EMBEDDING_API',
    );
    this.AZURE_EMBEDDING_API_KEY = this.configService.get<string>(
      'AZURE_EMBEDDING_API_KEY',
    );
    this.elasticSearchApiURL =
      this.configService.get<string>('ELASTICSEARCH_API');
    this.elasticSearchApiKey = this.configService.get<string>(
      'ELASTICSEARCH_API_KEY',
    );
  }
  async processFile(fileBuffer: Buffer): Promise<any[]> {
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const data: Translation[] = XLSX.utils.sheet_to_json(worksheet);
    const results = [];

    const englishTexts = data.map((t) => t.english);
    const chineseTexts = data.map((t) => t.chinese);

    const englishEmbeddings = await this.getEmbeddings(englishTexts);
    const chineseEmbeddings = await this.getEmbeddings(chineseTexts);

    for (let i = 0; i < data.length; i++) {
      const englishVector = englishEmbeddings[i].embedding;
      const chineseVector = chineseEmbeddings[i].embedding;

      results.push(
        { index: { _id: i + 1 } },
        {
          'english-vector': englishVector,
          'simplified-chinese-vector': chineseVector,
          'english-text': data[i].english,
          'simplified-chinese-text': data[i].chinese,
        },
      );
    }

    // Send the bulk request to Elasticsearch
    const response = await this.sendToElasticsearch(results);

    return response?.items;
  }

  // Function to get vector embeddings
  async getEmbeddings(texts) {
    try {
      const response = await axios.post(
        this.AZURE_EMBEDDING_API_URL,
        {
          input: texts,
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'api-key': this.AZURE_EMBEDDING_API_KEY,
          },
        },
      );
      return response.data.data;
    } catch (error) {
      throw new HttpException(error.response.data, error.response.status);
    }
  }

  // Function to perform bulk indexing
  async sendToElasticsearch(data) {
    try {
      // Format the data for bulk indexing
      const formattedData =
        data.map((item) => JSON.stringify(item)).join('\n') + '\n';

      const response = await axios.post(
        this.elasticSearchApiURL + '/language-index/_bulk?refresh=true',
        formattedData,
        {
          headers: {
            'Content-Type': 'application/x-ndjson', // Correct content type for NDJSON
            'kbn-xsrf': 'reporting', // Required for Kibana
            Authorization: `ApiKey ${this.elasticSearchApiKey}`,
          },
        },
      );
      return response.data;
    } catch (error) {
      if (error.response) {
        throw new HttpException(error.response.data, error.response.status);
      } else {
        throw new HttpException(
          'Error during bulk indexing',
          HttpStatus.INTERNAL_SERVER_ERROR,
        );
      }
    }
  }

  async searchText({ field, searchText }) {
    try {
      const searchEmbedding = await this.getEmbeddings([searchText]);

      const data = {
        knn: {
          field: field, //"english-vector",
          query_vector: searchEmbedding[0].embedding,
          k: 5,
          num_candidates: 10,
        },
        fields: ['english-text', 'simplified-chinese-text'],
        _source: ['english-text', 'simplified-chinese-text'],
      };
      const stringifyData = JSON.stringify(data);
      const headers = {
        'Content-Type': 'application/json',
        Authorization: `ApiKey ${this.elasticSearchApiKey}`,
      };

      const response = await axios.post(
        this.elasticSearchApiURL + '/language-index/_search',
        stringifyData,
        { headers },
      );
      return response?.data?.hits;
    } catch (error) {
      throw new HttpException(error.response.data, error.response.status);
    }
  }
}
