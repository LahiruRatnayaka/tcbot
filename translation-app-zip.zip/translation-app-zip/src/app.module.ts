import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TranslationsModule } from './translations/translations.module';
import { ConfigModule } from '@nestjs/config';
import { GlossaryModule } from './glossary/glossary.module';
import { MongooseModule } from '@nestjs/mongoose';

@Module({
  imports: [
    MongooseModule.forRoot('mongodb://localhost:27017/translator-db'),
    ConfigModule.forRoot({
      isGlobal: true, // Makes the module globally available
    }),
    TranslationsModule,
    GlossaryModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
