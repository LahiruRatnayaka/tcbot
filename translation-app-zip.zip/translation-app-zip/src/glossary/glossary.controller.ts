import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  HttpException,
  HttpStatus,
} from '@nestjs/common';
import { GlossaryService } from './glossary.service';
import { CreateGlossaryDto } from './dto/create-glossary.dto';
import { UpdateGlossaryDto } from './dto/update-glossary.dto';

@Controller('api/v1/glossary')
export class GlossaryController {
  constructor(private readonly glossaryService: GlossaryService) {}

  @Post()
  async create(@Body() createGlossaryDto: CreateGlossaryDto) {
    try {
      return await this.glossaryService.create(createGlossaryDto);
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @Get()
  async findAll() {
    try {
      return await this.glossaryService.findAll();
    } catch (error) {
      throw new HttpException(error.message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      const glossary = await this.glossaryService.findOne(id);
      if (!glossary) {
        throw new HttpException(
          'Glossary entry not found',
          HttpStatus.NOT_FOUND,
        );
      }
      return glossary;
    } catch (error) {
      if (error.status === HttpStatus.NOT_FOUND) {
        throw error;
      }
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateGlossaryDto: UpdateGlossaryDto,
  ) {
    try {
      const updatedGlossary = await this.glossaryService.update(
        id,
        updateGlossaryDto,
      );
      if (!updatedGlossary) {
        throw new HttpException(
          'Glossary entry not found',
          HttpStatus.NOT_FOUND,
        );
      }
      return updatedGlossary;
    } catch (error) {
      if (error.status === HttpStatus.NOT_FOUND) {
        throw error;
      }
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }

  @Delete(':id')
  async remove(@Param('id') id: string) {
    try {
      const deletedGlossary = await this.glossaryService.delete(id);
      if (!deletedGlossary) {
        throw new HttpException(
          'Glossary entry not found',
          HttpStatus.NOT_FOUND,
        );
      }
      return deletedGlossary;
    } catch (error) {
      if (error.status === HttpStatus.NOT_FOUND) {
        throw error;
      }
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
  }
}
