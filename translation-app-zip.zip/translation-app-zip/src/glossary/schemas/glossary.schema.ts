import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema()
export class Glossary extends Document {
  @Prop({ required: true, type: String })
  english: string;

  @Prop({ required: true, type: String })
  simplified_chinese: string;
}

export const GlossarySchema = SchemaFactory.createForClass(Glossary);
