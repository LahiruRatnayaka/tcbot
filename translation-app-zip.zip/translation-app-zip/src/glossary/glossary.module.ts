import { Module } from '@nestjs/common';
import { GlossaryService } from './glossary.service';
import { GlossaryController } from './glossary.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Glossary, GlossarySchema } from './schemas/glossary.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Glossary.name, schema: GlossarySchema },
    ]),
  ],
  providers: [GlossaryService],
  controllers: [GlossaryController],
})
export class GlossaryModule {}
