export class UpdateGlossaryDto {
  english?: string;
  simplified_chinese?: string;
}
