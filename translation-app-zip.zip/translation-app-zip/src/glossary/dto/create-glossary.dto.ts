export class CreateGlossaryDto {
  english: string;
  simplified_chinese: string;
}
