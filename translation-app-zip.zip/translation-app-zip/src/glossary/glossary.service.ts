import {
  Injectable,
  NotFoundException,
  BadRequestException,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Glossary } from './schemas/glossary.schema';
import { CreateGlossaryDto } from './dto/create-glossary.dto';
import { UpdateGlossaryDto } from './dto/update-glossary.dto';

@Injectable()
export class GlossaryService {
  constructor(
    @InjectModel(Glossary.name) private readonly glossaryModel: Model<Glossary>,
  ) {}

  async create(createGlossaryDto: CreateGlossaryDto): Promise<Glossary> {
    try {
      const createdGlossary = new this.glossaryModel(createGlossaryDto);
      return await createdGlossary.save();
    } catch (error) {
      throw new BadRequestException('Error creating glossary entry');
    }
  }

  async findAll(): Promise<Glossary[]> {
    try {
      return await this.glossaryModel.find().exec();
    } catch (error) {
      throw new InternalServerErrorException(
        'Error retrieving glossary entries',
      );
    }
  }

  async findOne(id: string): Promise<Glossary> {
    try {
      const glossary = await this.glossaryModel.findById(id).exec();
      if (!glossary) {
        throw new NotFoundException(`Glossary entry with id ${id} not found`);
      }
      return glossary;
    } catch (error) {
      if (error instanceof NotFoundException) {
        throw error;
      }
      throw new BadRequestException('Error retrieving glossary entry');
    }
  }

  async update(
    id: string,
    updateGlossaryDto: UpdateGlossaryDto,
  ): Promise<Glossary> {
    try {
      const updatedGlossary = await this.glossaryModel
        .findByIdAndUpdate(id, updateGlossaryDto, { new: true })
        .exec();
      if (!updatedGlossary) {
        throw new NotFoundException(`Glossary entry with id ${id} not found`);
      }
      return updatedGlossary;
    } catch (error) {
      if (error instanceof NotFoundException) {
        throw error;
      }
      throw new BadRequestException('Error updating glossary entry');
    }
  }

  async delete(id: string): Promise<Glossary> {
    try {
      const deletedGlossary = await this.glossaryModel
        .findByIdAndDelete(id)
        .exec();
      if (!deletedGlossary) {
        throw new NotFoundException(`Glossary entry with id ${id} not found`);
      }
      return deletedGlossary;
    } catch (error) {
      if (error instanceof NotFoundException) {
        throw error;
      }
      throw new BadRequestException('Error deleting glossary entry');
    }
  }
}
