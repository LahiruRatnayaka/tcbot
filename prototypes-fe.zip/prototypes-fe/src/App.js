import { createBrowserRouter, RouterProvider } from 'react-router-dom';

import './App.css';

// pages
import LayoutPage from "./pages/spark/layout-page"

// routes
import AppRoute from './routes/routes';

function App() {
  const router = createBrowserRouter([
    {
        element: <LayoutPage />,
        children: AppRoute.Pages
    },

]);
  return (
    <div className="App">
      <RouterProvider router = {router} />
    </div>
  );
}

export default App;
