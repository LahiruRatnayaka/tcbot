import React from 'react';

import HeaderNavbar from "../components/navbar"


// project-spark
const HomePage = React.lazy(() => import('../pages/spark/home-page'));

// project-red
const RedHomePage = React.lazy(() => import('../pages/project-red/home-page'));

/**
 * @description A constant used to define the route path of the application. 
 * Use suffix to differentiate among projects for routing and maintainance. 
 * Keys should be in UPPER_CASE for the path.
 * @example
 * // project-spark
 * HOME: '/',
 * // project-red
 * RED:{
 *    HOME: '/red',
 *    DETAIL: '/red/error/:id',
 * }
 * @returns {Object} routePath
 */

const brandImg = require("../assets/images/parent/spark_logo_transparent.png");
const spark = {
    img: {
        alt: "spark",
        src: brandImg,
        width: "60",
        height: "90",
        anchor: "#",
    },
    title: "SPARK",
    tagline: "// Where Ideas Meet Reality"
}

const RedbrandImg = require("../assets/images/project-red/red_logo.png");
const projectRed = {
    img: {
        alt: "project-red",
        src: RedbrandImg,
        width: "80",
        height: "80",
        anchor: "#",
    },
    title: 'PROJECT <span style="color:red">RED</span>',
    tagline: 'Reactive Error Detection Service'
}



const appRoutePaths = {
    // project-spark
    HOME: '/',

    // project-red
    RED:{
        HOME: '/red',
        DETAIL: '/red/error/:id',
    }

    // add another project here
    
}



const appRoutes = [
    // project-spark
    { path: appRoutePaths.HOME, element: <><header><HeaderNavbar brand={spark}/></header><div className="body-container"><HomePage/></div></> },
    // project-red
    { path: appRoutePaths.RED.HOME, element: <><header><HeaderNavbar brand={projectRed}/></header><div className="body-container"><RedHomePage/></div></>}, 

    // other
    // { path: '/404', element: <NotFoundPage /> },
    // { path: '*', element: <Navigate to="/404" /> },
]

const AppRoute = {
    Pages: appRoutes, 
    Paths: appRoutePaths
}

export default AppRoute