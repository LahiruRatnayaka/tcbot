import React from "react"
import Carousel from 'react-bootstrap/Carousel';
import AppCarouselsImg from './carouselsImg';

import "./carousels.css"


const AppCarousels = ({ items }) => {
    return (
      <Carousel fade>
        {
          items && items.map((item, index) => {
            return (
              <Carousel.Item key={index}>
                <AppCarouselsImg text={item.img.text} url={item.img.url} />
                <Carousel.Caption>
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </Carousel.Caption>
              </Carousel.Item>
            )
          })
        }
      </Carousel>
    )
}

export default AppCarousels;
