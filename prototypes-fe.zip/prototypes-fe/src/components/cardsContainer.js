import React from "react"

//components
import AppCard from "./cards";

// custom css
import "./cardsContainer.css"

const AppCardsContainer = ({ items }) => {
    return (
        <div className="cards-container">
            {
                items && items.map((item, index) => {
                    return (
                        <AppCard key={index} item={item}/>
                    )
                })
            }
      </div>
    )
}

export default AppCardsContainer;
