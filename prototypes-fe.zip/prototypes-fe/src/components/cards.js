import React from "react"

// react bootstrap
import Card from 'react-bootstrap/Card';
import { Link } from "react-router-dom";

// custom css
import "./cards.css"

const AppCard = ({ item }) => {
    return (
        <Card className="custom-card">
            <Card.Img className="custom-card-img" variant="top" src={item.img} />
            <Card.Body>
                <Card.Title>{item.title}</Card.Title>
                <Card.Text>
                    {item.description}
                </Card.Text>
                <Link className="btn bg-warning" to={item.link} variant="warning">Explore</Link>
            </Card.Body>
      </Card>
    )
}

export default AppCard;
