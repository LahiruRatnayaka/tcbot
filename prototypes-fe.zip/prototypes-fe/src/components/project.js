import React, { useEffect, useState } from "react"
import { useForm } from "react-hook-form"

import "./project.css"

import Row from 'react-bootstrap/Row';
import Col from "react-bootstrap/Col";
import ListGroup from 'react-bootstrap/ListGroup';

// components
import AppDropdown from "./dropdown";
import { Button } from "react-bootstrap";

// fontawesom
// fontawesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSquarePlus } from '@fortawesome/free-solid-svg-icons'

const registerUrl = `${process.env.REACT_APP_BASE_URL}/applications/post`;
const getAppsUrl = `${process.env.REACT_APP_BASE_URL}/applications/get`;



const Project = ({ callback, onAppChange, activeValue }) => {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const [ showRegistration, setShowRegistration ] = useState('d-none');
    const [ applications, setApplication ] = useState([]);

    useEffect(()=> {
        let dataFetched = false;
        const fetchRegisteredApplications = async () => {
            await fetch(getAppsUrl, { method: "GET"}).then(async (res) => {
                const result = await res.json();
                console.log('result', result);
                
                setApplication(result);
                dataFetched = true;
            }).catch((err) => {
                console.log('err', err);
            });
        }
        if(!dataFetched) {
            fetchRegisteredApplications();
        }
    }, []);

    const toggleResistrationContainer = (show) => {
        setShowRegistration(show === true ? '' : 'd-none');
    }


    const onFormSubmit = async (data) => {
        const formData = new FormData();
        formData.append("app", data.appName);
        formData.append("appDescription", data.appDescription);
        formData.append('logSample', data.logSample);
        formData.append('logPattern', data.logPattern );
        formData.append('logDatetimeRegex', data.logDatetimeRegex );
        formData.append('logCriticalLevel', data.logCriticalLogLevel );

        await fetch(registerUrl, { method: "POST", body: formData }).then(async (res) => {
            const result = await res.json();
            toggleResistrationContainer(false);
            //if(result.status) 
            //else 
        }).catch((err) => {
            console.log('err', err);
        });
    }

    return (
        <Row className="project-container">
            <Row>
                <Col xs={8}>
                    {/* <div className="project-title-container">
                        <h5>Select Your Log Analytics Application</h5>
                    </div> */}
                </Col>
                <Col xs={4}>
                    <div className="project-button-container">
                        <Button onClick={() => toggleResistrationContainer(true)} style={{float:"right"}} variant="secondary" > <FontAwesomeIcon icon={faSquarePlus} /></Button>
                        {
                            applications && applications.length > 0 ?
                            <AppDropdown 
                                title={activeValue} 
                                items={applications} 
                                fallback={(item) => onAppChange(item)} 
                                display={"Application"}
                                variant={"danger"}
                            />
                            : <></>
                        }
                    </div>
                </Col>


                <Col xs={12} className={showRegistration}>
                    <h6>Register Application Details & Metadata</h6>
                    <div className="project-form-container">
                        <form onSubmit={handleSubmit(onFormSubmit)}>
                            <Row>
                                <Col xs={6}>
                                    <div className="form-group">
                                        <label>Application Name</label>
                                        <input type="text" className="form-control" {...register("appName", { required: true })} />
                                        {errors.appName && <span>This field is required</span>}
                                    </div>
                                    <div className="form-group">
                                        <label>Appliation Description</label>
                                        <input type="text" className="form-control" {...register("appDescription", { required: true })} />
                                        {errors.appDescription && <span>This field is required</span>}
                                    </div>
                                    <div className="form-group">
                                        <label>Sample Log Entries</label>
                                        <input type="text" className="form-control" {...register("logSample", { required: true })} />
                                        {errors.appDescription && <span>This field is required</span>}
                                    </div>
                                </Col>
                                <Col xs={6}>
                                    <div className="form-group">
                                        <label>Log Pattern</label>
                                        <input type="text" className="form-control" {...register("logPattern", { required: true })} />
                                        {errors.appName && <span>This field is required</span>}
                                    </div>
                                    <div className="form-group">
                                        <label>Datetime Regex</label>
                                        <input type="text" className="form-control" {...register("logDatetimeRegex", { required: true })} />
                                        {errors.appDescription && <span>This field is required</span>}
                                    </div>
                                    <div className="form-group">
                                        <label>Critical Log Level</label>
                                        <input type="text" className="form-control" {...register("logCriticalLogLevel", { required: true })} />
                                        {errors.appDescription && <span>This field is required</span>}
                                    </div>
                                </Col>
                                <Col xs={12}>
                                    <div className="project-button-container">
                                        <Button onClick={() => toggleResistrationContainer(false)} variant="secondary" >Close</Button>
                                        <input style={{marginRight: '20px'}}  className="btn btn-success" value={"Register"} type="submit" />
                                    </div>
                                </Col>
                            </Row>
                        </form>
                    </div>
                </Col>      
               
            </Row>
        </Row>
    )
}

export default Project;