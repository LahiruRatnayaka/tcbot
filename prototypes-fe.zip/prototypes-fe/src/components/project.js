import React, { useEffect, useState } from "react"
import { useForm } from "react-hook-form"

import "./project.css"

import Row from 'react-bootstrap/Row';
import Col from "react-bootstrap/Col";
import ListGroup from 'react-bootstrap/ListGroup';

// components
import AppDropdown from "./dropdown";
import { Button } from "react-bootstrap";

// fontawesom
// fontawesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSquarePlus } from '@fortawesome/free-solid-svg-icons'

const registerUrl = `${process.env.REACT_APP_BASE_URL}/applications/post`;
const getAppsUrl = `${process.env.REACT_APP_BASE_URL}/applications/get`;



const Project = ({ callback, onAppChange, activeValue }) => {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const [ showRegistration, setShowRegistration ] = useState('d-none');
    const [ applications, setApplication ] = useState([]);

    useEffect(()=> {
        let dataFetched = false;
        const fetchRegisteredApplications = async () => {
            await fetch(getAppsUrl, { method: "GET"}).then(async (res) => {
                const result = await res.json();
                console.log('result', result);
                
                setApplication(result);
                dataFetched = true;
            }).catch((err) => {
                console.log('err', err);
            });
        }
        if(!dataFetched) {
            fetchRegisteredApplications();
        }
    }, []);

    const toggleResistrationContainer = (show) => {
        setShowRegistration(show === true ? '' : 'd-none');
    }


    const onFormSubmit = async (data) => {
        const formData = new FormData();
        formData.append("name", data.appName);
        formData.append("description", data.appDescription);
        formData.append('appTech', data.appTech );
        formData.append('logType', data.logType );

        formData.append('logSample', data.logSample);
        formData.append('logLevels', data.logLevels );
        formData.append('appInfraTech', data.appInfraTech );

        formData.append('logDatetimeRegex', data.logDatetimeRegex );
        formData.append('logJsonStructure', data.logJsonStructure );


        await fetch(registerUrl, { method: "POST", body: formData }).then(async (res) => {
            const result = await res.json();
            toggleResistrationContainer(false);
        }).catch((err) => {
            console.log('err', err);
        });
    }

    return (
        <Row className="project-container">
            <Row>
                <Col xs={8}>
                    {/* <div className="project-title-container">
                        <h5>Select Your Log Analytics Application</h5>
                    </div> */}
                </Col>
                <Col xs={4}>
                    <div className="project-button-container">
                        <Button onClick={() => toggleResistrationContainer(true)} style={{float:"right"}} variant="secondary" > <FontAwesomeIcon icon={faSquarePlus} /></Button>
                        {
                            applications && applications.length > 0 ?
                            <AppDropdown 
                                title={activeValue} 
                                items={applications} 
                                fallback={(item) => onAppChange(item)} 
                                display={"Application"}
                                variant={"danger"}
                            />
                            : <></>
                        }
                    </div>
                </Col>


                <Col xs={12} className={showRegistration}>
                    <h6>Register Application Details & Metadata</h6>
                    <div className="project-form-container">
                        <form onSubmit={handleSubmit(onFormSubmit)}>
                            <Row>
                                <Col xs={4}>
                                    <div className="form-group">
                                        <label>Name*</label>
                                        <input type="text" className="form-control" {...register("appName", { required: true })} />
                                        {errors.appName && <span>This field is required</span>}
                                    </div>
                                    <div className="form-group">
                                        <label>Description</label>
                                        <input type="text" className="form-control" {...register("appDescription")} />
                                    </div>
                                    <div className="form-group">
                                        <label>Application Technology</label>
                                        <input type="text" className="form-control" {...register("appTech")} />
                                    </div>
                                    <div className="form-group">
                                        <label>Log Pattern Type*</label>
                                        <select className="form-control" {...register("logType", { required: true })}>
                                            <option className="form-control" value="text">Plain Text</option>
                                            <option className="form-control" value="json">JSON</option>
                                        </select>
                                        {errors.logType && <span>This field is required</span>}
                                    </div>
                                   
                                </Col>
                                <Col xs={4}>
                                <div className="form-group">
                                        <label>Sample Log Entries</label>
                                        <textarea rows={4} className="form-control" {...register("logSample")} />
                                    </div>
                                  
                                    <div className="form-group">
                                        <label>Log Levels</label>
                                        <input type="text" className="form-control" {...register("logLevels")} />
                                    </div>
                                    <div className="form-group">
                                        <label>Infra Technology</label>
                                        <input type="text" className="form-control" {...register("appInfraTech")} />
                                    </div>
                                </Col>
                                <Col xs={4}>
                                <div className="form-group">
                                        <label>DateTime Regex</label>
                                        <input type="text" className="form-control" {...register("logDatetimeRegex")} />
                                    </div>
                                    <div className="form-group">
                                        <label>JSON Structure</label>
                                        <textarea rows={4} className="form-control" {...register("logJsonStructure")} />
                                    </div>
                                </Col>
                                <Col xs={12}>
                                    <div className="project-button-container">
                                        <Button onClick={() => toggleResistrationContainer(false)} variant="secondary" >Close</Button>
                                        <input style={{marginRight: '10px'}}  className="btn btn-light" value={"Register"} type="submit" />
                                    </div>
                                </Col>
                            </Row>
                        </form>
                    </div>
                </Col>      
               
            </Row>
        </Row>
    )
}

export default Project;