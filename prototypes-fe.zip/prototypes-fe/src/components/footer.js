import React from "react"
import "./footer.css"


const Footer = ({ children }) => {
    return (
        <div className="footer">
           <p className="footer-text"> ✨ SPARK: An initiative by Emerging and Foundation Technologies | Group Wealth Engineering - 2024</p>
        </div>
    )
}

export default Footer;

