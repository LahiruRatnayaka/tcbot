import React, { useEffect } from "react"
import { useState } from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle, faTimesCircle, faClock } from '@fortawesome/free-solid-svg-icons'

import "./modal.css"

const LogProccessingModal = ({ active, progress }) => {
  const [show, setShow] = useState(false);

  useEffect(() => { 
      if (active) { 
          setShow(true);
      }
  }, [active]);

  const handleClose = () => setShow(false);

  return (
    <>
      <Modal size="lg" show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Log Processing Progress</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div>
            { progress.map((item, index) => {
              let statusColor = item.status === 'pending' ? '#FFD43B' :  (item.status === 'success' ? '#128B37' : '#FF0000');
              let statusIcon = item.status === 'pending' ? faClock : (item.status === 'success' ? faCheckCircle : faTimesCircle);
              return (
                <div className="log-pg-m-status-container" key={index}>
                  <div className="log-pg-m-status-icon">
                    <FontAwesomeIcon size="lg" icon={statusIcon} color={statusColor} />
                  </div>
                  <div className="log-pg-m-text-container">
                    <div className="log-pg-m-text-title">{item.title}</div>
                    <div className="log-pg-m-text-desc">{item.description}</div>
                  </div>
                </div>
            )}
            )}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default LogProccessingModal;

