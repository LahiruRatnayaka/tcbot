import React from "react"

import "./carouselsImg.css"


const AppCarouselsImg = ({ text, url }) => {
    return (
       <img src={url} alt={text} />
    )
}

export default AppCarouselsImg;
