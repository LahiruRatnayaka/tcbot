import React, { useState } from 'react';
import Dropdown from 'react-bootstrap/Dropdown';

// custom css
import "./dropdown.css"

function AppDropdown(props) {
  const {title, items, variant, fallback, display} = props;
  const [selected, setSelected] = useState(title);

  const handleSelect = (selectedItem) => {
    setSelected(selectedItem[display]);
    fallback(selectedItem);
  }

  return (
    <div className='app-dropdown-container'>
      <Dropdown>
        <Dropdown.Toggle variant={variant ?? "default"} id="dropdown-basic">
          {title ?? "Select an Option"}
        </Dropdown.Toggle>

        <Dropdown.Menu>
          {
              items && items.map((item, index) => {
                  return (<Dropdown.Item onClick={() => fallback(item)} key={index}>{item[display]}</Dropdown.Item>)
              })
          }
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}

export default AppDropdown;