import React from "react"

// boostrap
import Container from 'react-bootstrap/Container'
import Nav from 'react-bootstrap/Nav'
import Navbar from 'react-bootstrap/Navbar'
import NavDropdown from 'react-bootstrap/NavDropdown'

import "./navbar.css"


const HeaderNavbar = ({brand, menus}) => {

    return (
        <Container>
           <Navbar expand="lg" className="custom-navbar">
                <Container>
                    <Navbar.Brand href="#home" className="custom-navbar-brand">
                        <img
                            alt={brand.img.alt ?? ""}
                            src={brand.img.src ?? ""}
                            width={brand.img.width ?? "30"}
                            height={brand.img.height ?? "30"}
                            className="d-inline-block align-top"
                        />{' '}
                        <div className="navbar-brand-title-container">
                            <h1 className="navbar-brand-title" dangerouslySetInnerHTML={{ __html: brand.title ?? "SPARK" }}></h1>
                            <div className="navbar-brand-tagline">{brand.tagline ?? "Where Ideas Meet Reality..."}</div>
                        </div>
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />

                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            {
                                menus?.left ? menus.left.map((menu, index) => {
                                    return (
                                        <Nav.Link href={menu.anchor} key={index}>{menu.title}</Nav.Link>    
                                    )
                                }) : <></>
                            }
                        </Nav>
                        <Nav>
                            {
                                 menus?.right ? menus.right.map((menu, index) => {
                                    return (
                                        <Nav.Link href={menu.anchor} key={index}>{menu.title}</Nav.Link>    
                                    )
                                }) : <></>
                            }
                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </Container>
    )
}

export default HeaderNavbar;

