import React, { useEffect, useState } from "react"
import { useForm } from "react-hook-form"

// react bootstrap
import Row from 'react-bootstrap/Row';
import Col from "react-bootstrap/Col";
import Container from 'react-bootstrap/Container';
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';

// components
import AppCarousels from "../../components/carousels";
import AppCardsContainer from "../../components/cardsContainer";

// fontawesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle, faTimesCircle, faClock } from '@fortawesome/free-solid-svg-icons'

// custom css
import "./home-page.css"

import AppRoute from "../../routes/routes";

// consts
const projectsData = [
  {
    "img":"https://i.ytimg.com/vi/CQZxeoQeo5c/maxresdefault.jpg",
    "title":"Project RED",
    "description":`GPT application designed to aid Relationship Managers in 
    swiftly navigating through research documents, encompassing structured, unstructured, 
    and real-time data. The project incorporates the RAG (Retrieve-Augment-Generate) 
    pattern alongside various advanced techniques in GPT application development.`,
    "link": AppRoute.Paths.RED.HOME
  },
  // {
  //   "img":"https://cdn.dribbble.com/users/1376399/screenshots/4177346/media/1161b1432d686a7e78a80a11d5bddf5c.png?compress=1&resize=400x300&vertical=top",
  //   "title":"Project RED",
  //   "description":`GPT application designed to aid Relationship Managers in 
  //   swiftly navigating through research documents, encompassing structured, unstructured, 
  //   and real-time data. The project incorporates the RAG (Retrieve-Augment-Generate) 
  //   pattern alongside various advanced techniques in GPT application development.`,
  //   "link":"Explore"
  // },
  // {
  //   "img":"https://i.ytimg.com/vi/CQZxeoQeo5c/maxresdefault.jpg",
  //   "title":"Project Phoenix",
  //   "description":`GPT application designed to aid Relationship Managers in 
  //   swiftly navigating through research documents, encompassing structured, unstructured, 
  //   and real-time data. The project incorporates the RAG (Retrieve-Augment-Generate) 
  //   pattern alongside various advanced techniques in GPT application development.`,
  //   "link":"Explore"
  // },
  // {
  //   "img":"https://th.bing.com/th/id/OIP.KAML2ZS6RmmRiR8W7hN9PAHaEp?rs=1&pid=ImgDetMain",
  //   "title":"CPO Copilot",
  //   "description":`GPT application designed to aid Relationship Managers in 
  //   swiftly navigating through research documents, encompassing structured, unstructured, 
  //   and real-time data. The project incorporates the RAG (Retrieve-Augment-Generate) 
  //   pattern alongside various advanced techniques in GPT application development.`,
  //   "link":"Explore"
  // },
  // {
  //   "img":"https://i.ytimg.com/vi/CQZxeoQeo5c/maxresdefault.jpg",
  //   "title":"Amigo",
  //   "description":`GPT application designed to aid Relationship Managers in 
  //   swiftly navigating through research documents, encompassing structured, unstructured, 
  //   and real-time data. The project incorporates the RAG (Retrieve-Augment-Generate) 
  //   pattern alongside various advanced techniques in GPT application development.`,
  //   "link":"Explore"
  // }
]

const carouselData = [
  {
    "img": {
      "url": "https://cdn.neowin.com/news/images/uploaded/2023/09/1696075943_windows_copilot.jpg",
      "text": "Microsoft Copilot",
    },
    "title":"Microsoft Copilot",
    "description":"Your Companion in Office",
  },
  {
    "img": {
      "url": "https://github.blog/wp-content/uploads/2021/06/GitHub-Copilot_social-card-1.png?fit=1200%2C630",
      "text": "GitHub Copilot",
    },
    "title":"GitHub Copilot",
    "description":"Your Code Companion for Development",
  },
  {
    "img": {
      "url": "https://cdn.neowin.com/news/images/uploaded/2023/09/1696075943_windows_copilot.jpg",
      "text": "Microsoft Copilot",
    },
    "title":"Microsoft Copilot",
    "description":"Your Companion in Office",
  }
]


const HomePage = () => {
    const [projects, setProjects] = useState([]);
    const [carousels, setCarousel] = useState([]);

    useEffect(() => { 
      setProjects(projectsData);
      setCarousel(carouselData)
    }, []);
      
    return (
      <Container>

        <Row className="carousel-row-container">
          <Col className="col-container-no-hr-padding" xs={12}>
              <AppCarousels items={carousels}/>
          </Col>
        </Row>
        
        <Row className="spark-row-container">
          <Col className="spark-info-container" xs={{ span: 10, offset: 1 }}>
            <div>
              <h5 className="spark-info-heading">An initiative by Emerging and Foundation Technologies | Group Wealth Engineering</h5>
              SPARK is a dynamic digital showcase designed to illuminate the brightest ideas and 
              groundbreaking projects from our team. This platform is not just a repository but a vibrant 
              community where creativity and innovation thrive. From initial sparks of inspiration to fully 
              realized prototypes and proof-of-concepts (PoCs), SPARK brings together the best of our 
              innovative endeavors. Whether you're a potential collaborator, an industry expert, 
              or just an innovation aficionado, SPARKS offers a window into the future, demonstrating 
              our commitment to pushing boundaries and exploring new frontiers. Join us on this journey 
              where every project tells a story of challenge, perseverance, and breakthrough.
            </div>
          </Col>
        </Row>
     
        <Row className="row-container">
          <Col className="col-container-no-hr-padding" xs={12}>
            <AppCardsContainer items={projects}/>
          </Col>
        </Row>
      </Container>
    )
}

export default HomePage;

