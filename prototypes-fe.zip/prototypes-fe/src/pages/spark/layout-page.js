import React, { Suspense } from "react"
import "./layout-page.css"

// route
import { Outlet } from 'react-router-dom'

// components
import Footer from "../../components/footer"

const brandImg = require("../../assets/images/parent/spark_logo_transparent.png");
const spark = {
    img: {
        alt: "spark",
        src: brandImg,
        width: "60",
        height: "90",
        anchor: "#",
    },
    title: "SPARK",
    tagline: "// Where Ideas Meet Reality"
}

const LayoutPage = () => {
    return (
        <div className="application-container">
            {/* <header>
                <HeaderNavbar brand={spark}/>
            </header>
            <div className="body-container">
              
            </div> */}

            <Suspense fallback={<div>Loading...</div>}>
                <Outlet/>
            </Suspense>
            <footer>
                <Footer/>
            </footer>
        </div>
    )
}

export default LayoutPage;