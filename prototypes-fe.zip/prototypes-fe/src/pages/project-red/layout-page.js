import React from "react"
import "./layout-page.css"

// components
import HeaderNavbar from "../../components/navbar"
import Footer from "../../components/footer"


const brandImg = require("../../assets/images/parent/spark_logo_transparent.png");
const projectRed = {
    img: {
        alt: "spark",
        src: brandImg,
        width: "60",
        height: "90",
        anchor: "#",
    },
    title: 'PROJECT <span style="color:red">RED</span>',
    tagline: 'Reactive Error Detection Service'
}

const RedLayoutPage = ({ children }) => {
    return (
        <div className="application-container">
            <header>
                <HeaderNavbar brand={projectRed}/>
            </header>
            <div className="body-container">
                {children}
            </div>
            <footer>
                <Footer/>
            </footer>
        </div>
    )
}

export default RedLayoutPage;