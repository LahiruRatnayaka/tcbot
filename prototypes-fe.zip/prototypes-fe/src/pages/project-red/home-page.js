import React, { useEffect, useState } from "react"
import { useForm } from "react-hook-form"

// components
import LogProccessingModal from "../../components/modal"
import Project from "../../components/project"

// bootstrap
import Row from 'react-bootstrap/Row';
import Col from "react-bootstrap/Col";
import Container from 'react-bootstrap/Container';
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Tab from 'react-bootstrap/Tab';
import Nav from 'react-bootstrap/Nav';
import Spinner from 'react-bootstrap/Spinner';
import Badge from 'react-bootstrap/Badge';
import Modal from 'react-bootstrap/Modal';

// fontawesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faCheckCircle, faTimesCircle, faClock } from '@fortawesome/free-solid-svg-icons'

// links
import "./home-page.css"

// chart js
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
  } from 'chart.js';
  import { Line } from 'react-chartjs-2';
  ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
  );
  

 const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
        text: '',
      },
    },
  };


// consts

console.log('base url', process.env.REACT_APP_BASE_URL);
const uploadUrl = `${process.env.REACT_APP_BASE_URL}/upload`;
const identifyUrl = `${process.env.REACT_APP_BASE_URL}/identify`;
const analyseUrl = `${process.env.REACT_APP_BASE_URL}/analyse`;
const remediateUrl = `${process.env.REACT_APP_BASE_URL}/remediate`;
const evaluationUrl = `${process.env.REACT_APP_BASE_URL}/evaluate`;

const logProcessingSteps = [
    {
        title: 'Pending log file upload',
        status: 'pending',
        description: '',
    },
    {
        title: 'Pending log file metadata identification',
        status: 'pending',
        description: '',
    },
   
    // {
    //     title: 'Analyse Log Entries',
    //     status: 'pending',
    //     description: '',
    // },
    // {
    //     title: 'Create Remidiation Plan & Report',
    //     status: 'pending',
    //     description: '',
    // },
]

const RedHomePage = () => {
    const { register, handleSubmit, formState: { errors } } = useForm();
    const [logPattern, setLogPattern] = useState();
    const [logName, setLogName] = useState();
    const [regex, setRegex] = useState();
    const [topLogLevel, setTopLogLevel] = useState();
    const [reportId, setReportId] = useState();
    const [logs, setLogs] = useState([]);
    const [remediationPlan, setRemediationPlan] = useState({ 'primaryReason':'', 'stepByStepGuide':[]});
    const [logEvaluation, setLogEvaluation] = useState([]);

    const [activeLogEntry, setActiveLogEntry] = useState('');
    const [application, setApplication] = useState({ 'id':0, 'name':'Select Log Analytics Application'});
    const [logType, setLogType] = useState('standard');

    // handle containers 
    const [showLogInputContainer, setShowLogInputContainer] = useState(false);
    const [showLogEntriesContainer, setshowLogEntriesContainer] = useState(false);
    const [showLogRemediationContainer, setshowLogRemediationContainer] = useState(false);
    const [showInsightLoader, setShowInsightLoader] = useState(false);
    const [showLogEvaluationContainer, setshowLogEvaluationContainer] = useState(false);
    const [showModal, setShowModal] = useState(false);
    
    // processing status
    const [processingStatus, setProcessingStatus] = useState(logProcessingSteps);
    // const [hasLogUploaded, setHasLogUploaded] = useState(false);
    const [showLogProgressModel, setShowLogProgressModel] = useState(false);


    // chart data
    const [chartData, setChartData] = useState({
        labels:[],
        datasets: [
          {
            label: 'log entry',
            data:[],
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
          }
        ],
      });
    
    /**
     * Function to update log processing status
     * @param {Number} idx - Index of the step by step process 
     * @param {String} status - Status of the process - pending | success | failed 
     * @param {String} description - Description of the process with additional details
     */
    const statusUpdate = (idx, title, status, description) => {
        let progress = [...processingStatus];
        progress[idx] = {...progress[idx], 
            status: status,
            description: description,
            title: title,
        }
        setProcessingStatus(progress)
    }

    /**
     * Triggered when log file is uploaded by user
     * @param {Object<File>} data - multipart form data with file
     */
    const onLogFileUploaded = async (data) => {
        const formData = new FormData();
        formData.append("file", data.file[0]);


        // show progress of log processing modal
        setShowLogProgressModel(true);

        await fetch(uploadUrl, { method: "POST", body: formData }).then(async (res) => {
            const result = await res.json();
          
            if(result.status) statusUpdate(0, 'Log file uploaded successfully', 'success', result.data.id)
            else statusUpdate(0, 'Error has occured while uploding log file', 'failed', result.message);
            setLogName(result.data.file);
        }).catch((err) => {
            statusUpdate(0, 'Error has occured while uploding log file', 'failed', err);
            console.log('err', err);
        });
    }

    /**
     * After successful log file upload, identify metadata for the log file
     */
    useEffect(() => {
        const identifyMetadataForLog = async () => {
            const formData = new FormData();
            formData.append("filename", logName);
            formData.append("appId", application.id);

            await fetch(identifyUrl, { method: "POST", body: formData }).then(async (res) => {
                const result = await res.json();
                statusUpdate(1, 'Log file metadata identified successfully', 'success', result.data.pattern);
                setLogPattern(result.data.pattern);
                setRegex(result.data.datetime);
                setTopLogLevel(result.data.severity.top);
                setshowLogEntriesContainer(true);
                console.log('metadata', result);
            }).catch((err) => {
                statusUpdate(1, 'Error has occured while identifying metadata', 'failed', err);
                console.log('err', err);
            });
        }
        if (logName) { 
            identifyMetadataForLog();
        }
    }, [logName]);





    /**
     * After successful metadata identification, analyse log file
     */
    useEffect(() => {
        const analyseLogFile = async () => {
            const formData = new FormData();
            formData.append("filename", logName);
            formData.append("pattern", logPattern);
            formData.append('level', '' );
            formData.append('regex', regex );
            formData.append("appId", application.id);

            await fetch(analyseUrl, { method: "POST", body: formData }).then(async (res) => {
                const result = await res.json();
                console.log('result', result);
                setShowLogProgressModel(false);
                setLogType(result.data.type);
                setLogs(result.data.logs);
                // statusUpdate(2, 'success', result.data.summary);
              //  setLogPattern(result.data.pattern);
            }).catch((err) => {
               // statusUpdate(2, 'failed', err);
                console.log('err', err);
            });
        }

        const evaluateLogEntries = async () => {
            const formData = new FormData();
            formData.append("filename", logName);
            formData.append("appId", application.id);
            await fetch(evaluationUrl, { method: "POST", body: formData }).then(async (res) => {
                const result = await res.json();
                console.log('result', result);
                setLogEvaluation(result.data.result);
                setshowLogEvaluationContainer(true);
            }).catch((err) => {
                console.log('err', err);
            });
        }

        if (logPattern) { 
            evaluateLogEntries();
            analyseLogFile();
            
        }
    }, [logPattern]);


    const updateChartData = (entry) => {

        const allEntries = entry.subEntries.reduce((agg, curr) => {
            if (agg[curr.timestamp]) {
                agg[curr.timestamp] += 1;
            } else {
                agg[curr.timestamp] = 1;
            }
            return agg
        },{});

        console.log('agg', allEntries);
        
        const values =  {...chartData.datasets[0]};
        const updatedValue = {
            ...values, 
            data:Object.values(allEntries),
        }
        console.log('values', updatedValue);
        const updateData = {
            ...chartData,
            labels:Object.keys(allEntries),
            datasets:[updatedValue]
        }
        console.log('updated data values', updateData);
        setChartData(updateData);

    }

    // remediation plan
    const getRemediationPlan = async (log, entry) => {

             updateChartData(entry);
            setshowLogRemediationContainer(false);
            setShowModal(true);
            setShowInsightLoader(true);
            const formData = new FormData();
            formData.append("logEntry", log);
            formData.append("pattern", logPattern);

            setActiveLogEntry(log);

            await fetch(remediateUrl, { method: "POST", body: formData }).then(async (res) => {
                const result = await res.json();
                let updatedPlan = {...remediationPlan, 
                    'primaryReason': result.data.primaryReason, 
                    'stepByStepGuide': result.data.stepByStepGuide
                };
                setShowInsightLoader(false);
                setshowLogRemediationContainer(true);
                setRemediationPlan(updatedPlan);
                console.log('remediate', result);
                scrollTo('remidiation-plan');
            }).catch((err) => {
                console.log('err', err);
            });
            
        //remediateUrl
    }

    const onAppChange = (appData) => {
        console.log('appData', appData);
        const updatedApp = {
            ...application,
            name: appData.Application,
            id: appData.rowKey
        };
        setApplication(updatedApp)
        setShowLogInputContainer(true);
    }

    const scrollTo = (hash) => {
        window.location.hash = "#" + hash;
    }

    


    return (
        <Container>
            <Project onAppChange = {onAppChange} activeValue={application.name}/> 
            {
                showLogInputContainer ?  
                <Row className="connect-log-container">
                    <div className="connect-log-title-container">
                        <h5>{application.name === 'Select Log Analytics Application' ? '' : application.name }</h5>
                    </div>
                    <Col>
                        <div>
                            <h6>Upload Your Log File</h6>
                            <p className="connect-log-para"> Only log files smaller than 4 MB are accepted for upload to ensure optimal system performance and security. Please check your file size before uploading.</p>

                            <form onSubmit={handleSubmit(onLogFileUploaded)}>
                                <input type="file" className="form-control" {...register("file", { required: true })} />
                                {errors.file && <span>This field is required</span>}
                                <div className="connect-log-button-container">
                                    <input  className="btn btn-dark" type="submit" />
                                </div>
                            </form>
                        </div>
                    </Col>
                    <Col>
                        <div>
                            <h6>Connet to Enterprice Log System</h6>
                            <p className="connect-log-para"> Get ready to have your mind blown because this function is about to be unleashed  in all its glorious awesomeness! Stay tuned for the big reveal, it's coming soon.</p>

                            <div className="form-group">
                                <input disabled type="text" className="form-control" />
                            </div>

                            <div>
                            <div className="connect-log-button-container">
                                    <input  className="btn btn-dark" value={"Connect"} type="submit" />
                                </div>
                            </div>
                        </div>
                    </Col>
                    <Col>
                        <div>
                            <h6>Log Analysis in Progress</h6>
                            <div>
                            { processingStatus.map((item, index) => {
                                let statusColor = item.status === 'pending' ? '#FFD43B' :  (item.status === 'success' ? '#128B37' : '#FF0000');
                                let statusIcon = item.status === 'pending' ? faClock : (item.status === 'success' ? faCheckCircle : faTimesCircle);
                                return (
                                    <div className="log-pg-m-status-container" key={index}>
                                    <div className="log-pg-m-status-icon">
                                        <FontAwesomeIcon size="lg" icon={statusIcon} color={statusColor} />
                                    </div>
                                    <div className="log-pg-m-text-container">
                                        <div className="log-pg-m-text-title">{item.title}</div>
                                        <div className="log-pg-m-text-desc">{item.description}</div>
                                    </div>
                                    </div>
                            )}
                            )}
                            </div>
                        </div>
                    </Col>
            {/* <LogProccessingModal active={showLogProgressModel} progress={processingStatus} /> */}
                </Row>: <></>
            }
            
            {
                /**
                 * Standard log evaluationb
                 * 
                 */
            }

{
showLogEvaluationContainer? <Row className="evaluation-log-container">
<div className="connect-log-title-container">
    <h5>Log Entries Evaluations</h5>
</div>
<Col xs={12}>
  <Table bordered striped hover >
    <thead>
        <tr>
            <th>Rule/Standards</th>
            <th>Evaluation</th>
            <th>Remarks</th>
        </tr>
    </thead>
    <tbody>
        {
            logEvaluation.length > 0 ? logEvaluation.map((log, index) => {
                let icon =  log.evaluation === 'PASSED' ? faCheckCircle : faTimesCircle;
                let iconColor = log.evaluation === 'PASSED' ? '#128B37' : '#FF0000';

                return (
                    <tr key={index}>
                        <td>{log.rule}</td>
                        <td><FontAwesomeIcon icon={icon} color={iconColor}/> </td>
                        <td>{log.reason === '' ? '-' : log.reason}</td>
                    </tr>
                )
            }): <p>No log entries found</p>
        }
        
    </tbody>
  </Table>
</Col>

{/* <LogProccessingModal active={showLogProgressModel} progress={processingStatus} /> */}
</Row> : <></>


}
           


            {/**
             * log entries container
             */}


            {
                showLogEntriesContainer ?  <Row className="log-entry-container">
                <div className="log-entry-title-container">
                        <h5>Log Entries</h5>
                </div>
             
                <Col xs={12}>
                                      
                 
                    <Tab.Container id="left-tabs-example" defaultActiveKey="error">
                        <Row>
                            <Col sm={2}>
                                <Nav variant="pills" className="flex-column">
                                    {
                                        logs.length > 0 ? logs.map((log, idx) => (
                                        <Nav.Item key={`${log.level}_${idx}`}>
                                            <Nav.Link eventKey={log.level}>{`${log.level.toUpperCase()} (${log.count})`}</Nav.Link>
                                        </Nav.Item>
                                        
                                        )) : <></>
                                    }
                                </Nav>
                            </Col>
                            <Col sm={10}>
                                <div className="log-entry-tab-container">
                                    <p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>

                                    <Tab.Content>   
                                        {
                                        logs.length > 0 ? logs.map((log, idx) => (
                                            <Tab.Pane key={idx} eventKey={log.level}>
                                                <Table striped bordered hover responsive>
                                                        <thead>
                                                            <tr>
                                                                <th>#</th>
                                                                <th>Log Entry</th>
                                                            </tr>
                                                        </thead>
                                                            <tbody>
                                                                {
                                                                    log.entries.map((entry, index) => {
                                                                        return (
                                                                            <tr  onClick={() => getRemediationPlan(JSON.stringify(entry.original), entry)} key={index}>
                                                                                <td>{index + 1}</td>
                                                                                <td className="log-entry-row">
                                                                                    {   
                                                                                    
                                                                                        <>
                                                                                            { entry.original} <br />
                                                                                            {entry.subEntries.length > 1 ? <> 
                                                                                             <Badge  style={{marginRight: 10}}  bg="warning" text="dark">{entry.subEntries.length} entries </Badge>
                                                                                          
                                                                                            </> : <></>}

                                                                                            <Badge bg="light" text="dark">{entry.timestamp} </Badge>

                                                                                        </> 
                                                                                    }
                                                                                
                                                                                </td>
                                                                            </tr>
                                                                        )
                                                                    })
                                                                }
                                                            </tbody>
                                                        </Table>
                                        
                                            </Tab.Pane> ))  : <p  className="connect-log-para">No log entries found</p>
                                        }



                                        {/* <Tab.Pane eventKey="fatal">
                                        {
                                            logs.fatal.length > 0 ?
                                            <>
                                            <p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>
                                            <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.fatal.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                                {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table>
                                            </>
                                                :<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane>
                                        <Tab.Pane eventKey="error">
                                        {
                                            logs.error.length > 0 ?
                                            <><p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>
                                                <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.error.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                            {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table></>:<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane>
                                        <Tab.Pane eventKey="warn">
                                        {
                                            logs.warn.length > 0 ?
                                            <><p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>

                                                <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.warn.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                            {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table></>:<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane>

                                        <Tab.Pane eventKey="info">
                                        {
                                            logs.info.length > 0 ?
                                            <><p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>

                                                <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.info.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                            {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table></>:<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane>

                                        <Tab.Pane eventKey="debug">
                                        {
                                            logs.debug.length > 0 ?
                                            <><p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>

                                                <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.debug.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                            {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table></>:<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane>

                                        <Tab.Pane eventKey="trace">
                                        {
                                            logs.trace.length > 0 ?
                                            <><p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>

                                                <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.trace.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                            {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table></>:<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane>

                                        <Tab.Pane eventKey="unknown">
                                        {
                                            logs.unknown.length > 0 ?
                                            <><p className="connect-log-para"> Click on a log entry to uncover the reason and the remediation plan.</p>

                                                <Table striped bordered hover responsive>
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Log Entry</th>
                                                        </tr>
                                                    </thead>
                                                        <tbody>
                                                            {
                                                                logs.unknown.map((log, index) => {
                                                                    return (
                                                                        <tr  onClick={() => getRemediationPlan(JSON.stringify(log))} key={index}>
                                                                            <td>{index + 1}</td>
                                                                            <td className="log-entry-row">
                                                                            {   
                                                                                    logType === 'standard' ?
                                                                                    <>
                                                                                    <b>Timestamp: </b> {log.timestamp} <br />
                                                                                    <b>Logger: </b> {log.logger} <br />
                                                                                    <b>Message: </b> {log.msg} 
                                                                                    </> : <>{log}</>
                                                                                }
                                                                            </td>
                                                                        </tr>
                                                                    )
                                                                })
                                                            }
                                                        </tbody>
                                                    </Table></>:<p  className="connect-log-para">No log entries found</p>
                                        }
                                        </Tab.Pane> */}
                                    </Tab.Content>
                                </div>
                            </Col>
                        </Row>
                    </Tab.Container>
                </Col>

               
                <Col xs={12}>
                    <div className="prompt-container">
                        <Form>
                            <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                                <Form.Control as="textarea" placeholder="Ask your question" rows={3} />
                            </Form.Group>
                            <Form.Group className="mb-3 prompt-button-container" controlId="exampleForm.ControlTextarea1">
                                <Button variant="outline-primary">User activity & behavior</Button>
                                <Button variant="outline-primary">Security Incidents</Button>
                                <Button variant="outline-primary">Potential Issues</Button>
                                <Button variant="outline-primary">Error Messages & Stack Trace</Button>
                                <Button variant="primary">Free Query</Button>
                            </Form.Group>
                        </Form>
                    </div>
                </Col>
                        
                    
            
    
            </Row>: <></>

            }


        <Modal
            show={showModal}
            onHide={() => setShowModal(false)}
            dialogClassName="modal-90w"
            aria-labelledby="example-custom-modal-styling-title"
        >
        <Modal.Header closeButton>
          <Modal.Title id="example-custom-modal-styling-title">
            Log Entry Insights
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <Row>

            </Row>
            <Row>
                <Col xs={7}>
                <Line options={options} data={chartData} />
                    {/* <Scatter options={options} data={chartData} /> */}
                </Col>
                <Col xs={5}>
                  
                {
                    showLogRemediationContainer ? 
                    <>
                        <h5 id="#remidiation-plan">Remediation Plan</h5>
                            <Col className="remediation-container" xs={12}>
                                <h6>Original Log</h6>
                                <p>{activeLogEntry}</p>

                                <h6>Primary Reason</h6>
                                <p>{remediationPlan.primaryReason}</p>

                                <br />
                                <h6>Step by Step Guide for Remediation</h6>
                                <ul>
                                    {
                                        remediationPlan.stepByStepGuide.map((step, index) => {
                                            return (
                                                <li key={index}>
                                                    <div><b>{step.title}</b></div>
                                                    <div>{step.description}</div>
                                                </li>
                                            )
                                        })
                                    }
                                </ul>
                                </Col>
                        </>
                        : <Col xs={12}>
                            {
                                showInsightLoader ? <>
                                <Button variant="success" disabled>
                                    <Spinner
                                    as="span"
                                    animation="grow"
                                    size="sm"
                                    role="status"
                                    aria-hidden="true"
                                    />
                                    &nbsp;Loading Remediation Plan...
                                </Button>
                                </> : <></>
                            }
                        </Col>


                }


            









                </Col>
                
            </Row>
        </Modal.Body>
      </Modal>
       
        </Container>

    )
}

export default RedHomePage;

