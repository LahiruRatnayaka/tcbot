# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- Initial project setup

### Changed

- Updated dependencies

### Fixed

- Bug fixes

## [1.0.0] - YYYY-MM-DD

### Added

- Feature 1
- Feature 2

### Changed

- Updated UI design

### Fixed

- Bug fixes

