using Microsoft.Azure.Cosmos;
using sephira.app.Interfaces;
using sephira.app.Interfaces.databases;
using sephira.app.Services;
using sephira.llm;
using sephira.db.az.cosmos;
using sephira.repo.github;
using sephira.db.az.tables;
using Microsoft.Extensions.DependencyInjection;

namespace sephira.api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Configuration.AddEnvironmentVariables();
            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();


            // Application - (DI) Infrastructure services

            // NoSql Db Service - Az Cosmos Db
            // Register CosmosClient
            builder.Services.AddSingleton<CosmosClient>(serviceProvider =>
            {
                var configuration = serviceProvider.GetRequiredService<IConfiguration>();
                string account = configuration["AZ_COSMOS_DB_ACCOUNT"];
                string key = configuration["AZ_COSMOS_DB_KEY"];
                return new CosmosClient(account, key);
            });

            // Register Cosmos Db Service
            builder.Services.AddSingleton<ICosmosDbService>(serviceProvider =>
            {
                var cosmosClient = serviceProvider.GetRequiredService<CosmosClient>();
                var configuration = serviceProvider.GetRequiredService<IConfiguration>();
                string databaseName = configuration["AZ_COSMOS_DB_NAME"];
                return new CosmosDbService(cosmosClient, databaseName);
            });

            // Register Table Storage Service
            builder.Services.AddSingleton<ITableStorageService>(serviceProvider =>
            {
                var configuration = serviceProvider.GetRequiredService<IConfiguration>();
                var connectionString = configuration["SEPHIRA_AZ_TABLE_STORAGE_CS"];
                return new TableStorageService(connectionString);
            });

            // Http Request Service - Default
            builder.Services.AddHttpClient<HttpRequestService>();
            // builder.Services.AddScoped<IHttpRequestExecutor, HttpRequestExecutor>();

            // Llm Service - Open AI
            builder.Services.AddScoped<ILlmService>(serviceProvider =>
            {
                var configuration = serviceProvider.GetRequiredService<IConfiguration>();
                string endpoint = configuration["AZURE_OPENAI_ENDPOINT"];
                string apiKey = configuration["AZURE_OPENAI_API_KEY"];
                string model = configuration["AZURE_OPENAI_MODEL_NAME"];
                return new OpenAiService(endpoint, apiKey, model);
            });
            // builder.Services.AddScoped<ILlmServiceExecutor, OpenAiExecutor>();

            // Application - (DI) Application services
            builder.Services.AddScoped<IRunServices, RunServices>();
            builder.Services.AddScoped<IReqService, ReqService>();
            builder.Services.AddScoped<IScenarioService, ScenarioService>();
            builder.Services.AddScoped<ISwaggerService, SwaggerService>();
            builder.Services.AddScoped<IRepoService, RepoService>();
            builder.Services.AddScoped<IRepoConnector, GithubConnector>();

            // Cors - Manage Cors 
            builder.Services.AddCors(p => p.AddPolicy("sephira-api-cors", builder =>
            {
                builder.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
            }));

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseCors("sephira-api-cors");

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
