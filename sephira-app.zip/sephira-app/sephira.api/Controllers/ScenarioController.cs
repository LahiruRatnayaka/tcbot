﻿using Microsoft.AspNetCore.Mvc;
using sephira.app.Interfaces;
using sephira.app.Models.Run.PayloadModels;

namespace sephira.api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class ScenarioController : ControllerBase
    {
        private readonly ILogger<RunController> _logger;
        private readonly IScenarioService _scenarioServices;

        public ScenarioController(ILogger<RunController> logger, IScenarioService scenarioService)
        {
            _logger = logger;
            _scenarioServices = scenarioService;
        }

        [HttpGet]
        [Route("templates")]
        public async Task<IActionResult> GetTeamplates()
        {
            var result = await _scenarioServices.GetScenarioTemplates();
            return Ok(result);
        }
    }
}

