﻿using Microsoft.AspNetCore.Mvc;
using sephira.app.Interfaces;
using sephira.app.Models.Run.PayloadModels;

namespace sephira.api.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class RunController : ControllerBase
    {
        private readonly ILogger<RunController> _logger;
        private readonly IRunServices _runServices;

        public RunController(ILogger<RunController> logger, IRunServices runServices)
        {
            _logger = logger;
            _runServices = runServices;
        }

        [HttpPost]
        [Route("initiate")]
        public async Task<IActionResult> InitiateRun([FromBody] RunInitiatePayload payload)
        {
            if (payload == null)
            {
                return BadRequest("Missing input parameters");
            }
            var result = await _runServices.InitiateRun(payload);
            return Ok(result);
        }

        [HttpPost]
        [Route("{runId}/scenarios")]
        public async Task<IActionResult> GetScenarios(string runId)
        {
            if (string.IsNullOrEmpty(runId))
            {
                return BadRequest("Missing input parameters");
            }
            var result = await _runServices.GeRunningScenarios(runId);
            return Ok(result);
        }

        [HttpPost]
        [Route("{runId}/scenarios/{scenarioSeq}/steps")]
        public async Task<IActionResult> GetScenarioSteps(string runId, int scenarioSeq)
        {
            var result = await _runServices.GetRunningScenarioSteps(runId, scenarioSeq);
            return Ok(result);
        }

        [HttpPost]
        [Route("{runId}/scenarios/{scenarioSeq}/steps/{stepSeq}")]
        public async Task<IActionResult> ExecuteScenarioStepRun(string runId, int scenarioSeq, int stepSeq, [FromBody] RunStepExecutionPayload? payload)
        {
            var result = await _runServices.ExecuteScenarioStep(runId, scenarioSeq, stepSeq, payload);
            return Ok(result);
        }

        [HttpPost]
        [Route("{runId}/scenario/{scenarioSeq}/interactions")]
        public async Task<IActionResult> GetRunScenarioInteractions(string runId, int scenarioSeq)
        {
            var result = await _runServices.GetRunScenarioInteractions(runId, scenarioSeq);
            return Ok(result);
        }
    }
}

