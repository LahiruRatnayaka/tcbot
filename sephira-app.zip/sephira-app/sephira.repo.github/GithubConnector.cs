﻿using LibGit2Sharp;
using sephira.app.Interfaces;

namespace sephira.repo.github
{
    public class GithubConnector : IRepoConnector
    {
        public GithubConnector()
        {
                
        }

        public string CloneRepo(string cloneUrl)
        {
            string localPath = $"C:/temp/sephira/github/{Guid.NewGuid().ToString("N")}";
            try
            {
                Console.WriteLine($"Cloning repository from {cloneUrl} to {localPath}");
                Repository.Clone(cloneUrl, localPath);

                return localPath;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
                return localPath;
            }
        }
       
    }
}
