﻿using sephira.app.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

public class HttpRequestExecutor : IHttpRequestExecutor
{
    private readonly HttpClient _httpClient;

    public HttpRequestExecutor(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<string> ExecuteRequestAsync(string url, HttpMethod method, HttpContent content = null, IDictionary<string, string> headers = null)
    {
        try
        {
            var request = new HttpRequestMessage(method, url);

            if (content != null)
            {
                request.Content = content;
            }

            if (headers != null)
            {
                foreach (var header in headers)
                {
                    request.Headers.Add(header.Key, header.Value);
                }
            }

            var response = await _httpClient.SendAsync(request);

            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync();
        }
        catch (Exception ex)
        {
            // Handle or log the exception as needed
            throw new ApplicationException($"Error executing request: {ex.Message}", ex);
        }
    }
}