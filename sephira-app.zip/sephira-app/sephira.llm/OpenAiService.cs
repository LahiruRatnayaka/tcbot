﻿using Azure;
using Azure.AI.OpenAI;
using sephira.app.Enums;
using sephira.app.Interfaces;
using sephira.app.Models.Common.Llm;


namespace sephira.llm
{
    public class OpenAiService : ILlmService
    {
        private string _endpoint;
        private string _apiKey;
        private string _model;

        public OpenAiService(string endpoint, string apiKey, string model)
        {
            _endpoint = endpoint;
            _apiKey = apiKey;
            _model = model;
        }

        public string Execute(LlmConfig config, List<LlmMessage> messages)
        {

            OpenAIClient client = new(new Uri(_endpoint), new AzureKeyCredential(_apiKey));
            var chatCompletionsOptions = new ChatCompletionsOptions()
            {
                DeploymentName = _model,
                Temperature = config.Temparature,
            };

            if (config.enableJsonOutput) {
                chatCompletionsOptions.ResponseFormat = ChatCompletionsResponseFormat.JsonObject;
            };

            if (messages.Count > 0)
            {
                for (int i = 0; i < messages.Count; i++)
                {
                    var message = messages[i];
                    switch (message.Role)
                    {
                        case LlmRole.SYSTEM:
                            chatCompletionsOptions.Messages.Add(new ChatRequestSystemMessage(message.Content));
                            break;
                        case LlmRole.USER:
                            chatCompletionsOptions.Messages.Add(new ChatRequestUserMessage(message.Content));
                            break;
                        case LlmRole.ASSISTANT:
                            chatCompletionsOptions.Messages.Add(new ChatRequestAssistantMessage(message.Content));
                            break;
                        default:
                            chatCompletionsOptions.Messages.Add(new ChatRequestUserMessage(message.Content));
                            break;
                    }
                }
            }
            Response<ChatCompletions> response = client.GetChatCompletions(chatCompletionsOptions);
            string responseMessage = response.Value.Choices[0].Message.Content;
            return responseMessage;
        }
    }
}

