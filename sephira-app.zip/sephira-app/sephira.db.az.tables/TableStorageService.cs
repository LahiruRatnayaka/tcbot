﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Azure;
using Azure.Data.Tables;
using Azure.Data.Tables.Models;
using Newtonsoft.Json;
using sephira.app.Interfaces.databases;

namespace sephira.db.az.tables
{
    public class TableStorageService : ITableStorageService
    {
        private readonly string _connectionString;

        public TableStorageService(string connectionString)
        {
            _connectionString = connectionString;
        }

        private TableClient GetTableClient(string tableName)
        {
            var serviceClient = new TableServiceClient(_connectionString);
            return serviceClient.GetTableClient(tableName);
        }

        public async Task<T> GetItemAsync<T>(string tableName, string partitionKey, string rowKey) where T : class, ITableEntity, new()
        {
            var tableClient = GetTableClient(tableName);
            var response = await tableClient.GetEntityAsync<T>(partitionKey, rowKey);
            return response.Value;
        }

        public async Task<List<T>> GetItemByQueryAsync<T>(string tableName, string partitionKey) where T : class, ITableEntity, new()
        {
            var tableClient = GetTableClient(tableName);
            var response =  tableClient.QueryAsync<T>(entity => entity.PartitionKey == partitionKey);
            List<T> results = new List<T>();
            await foreach (Page<T> page in response.AsPages())
            {
                foreach (T qEntity in page.Values)
                {
                    results.Add(qEntity);
                }
            }
            return results;
        }

        public async Task<List<T>> GetItemsByFilterAsync<T>(string tableName, string filterQuery) where T : class, ITableEntity, new()
        {
            var tableClient = GetTableClient(tableName);
            var response = tableClient.QueryAsync<T>(filterQuery);
            List<T> results = new List<T>();

            await foreach (Page<T> page in response.AsPages())
            {
                foreach (T entity in page.Values)
                {
                    results.Add(entity);
                }
            }

            return results;
        }

        public async Task<List<T>> GetItemsAsync<T>(string tableName) where T : class, ITableEntity, new()
        {
            var tableClient = GetTableClient(tableName);
            var entities = tableClient.QueryAsync<T>();
            var results = new List<T>();
            await foreach (var entity in entities)
            {
                results.Add(entity);
            }
            return results;
        }

        public async Task<bool> AddItemAsync<T>(string tableName, T item) where T : class, ITableEntity
        {
            bool isSuccessful = false;
            var tableClient = GetTableClient(tableName);
            try
            {
                await tableClient.AddEntityAsync(item);
                isSuccessful = true;
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return isSuccessful;
        }

        public async Task<bool> UpdateItemAsync<T>(string tableName, T item) where T : class, ITableEntity
        {
            var tableClient = GetTableClient(tableName);
            bool isSuccessful = false;
            try
            {
                await tableClient.UpsertEntityAsync(item, TableUpdateMode.Replace);
                isSuccessful = true;
            }
            catch (RequestFailedException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return isSuccessful;
        }

        public async Task<bool> AddItemsAsync<T>(string tableName, List<T> items) where T : class, ITableEntity
        {
            bool isSuccessful = false;
            var tableClient = GetTableClient(tableName);
            try
            {
                foreach (var item in items)
                {
                    await tableClient.AddEntityAsync(item);
                }
                isSuccessful = true;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return isSuccessful;
        }
        public async Task DeleteItemAsync(string tableName, string partitionKey, string rowKey)
        {
            var tableClient = GetTableClient(tableName);
            await tableClient.DeleteEntityAsync(partitionKey, rowKey);
        }
    }
}
