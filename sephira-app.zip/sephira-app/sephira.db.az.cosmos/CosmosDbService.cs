﻿using Microsoft.Azure.Cosmos;
using sephira.app.Interfaces.databases;

namespace sephira.db.az.cosmos
{
    public class CosmosDbService : ICosmosDbService
    {
        private readonly CosmosClient _dbClient;
        private readonly string _database;

        public CosmosDbService(CosmosClient dbClient, string databaseName)
        {
            _dbClient = dbClient;
            _database = databaseName;
        }

        public async Task<T> GetItemAsync<T>(string containerName, string id, string partitionKey)
        {
            Container _container = _dbClient.GetContainer(_database, containerName);
            try
            {
                ItemResponse<T> response = await _container.ReadItemAsync<T>(id, new PartitionKey(partitionKey));
                return response.Resource;
            }
            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return default;
            }
        }

        public async Task<IEnumerable<T>> GetItemsAsync<T>(string containerName, string query)
        {
            Container _container = _dbClient.GetContainer(_database, containerName);

            var queryDefinition = new QueryDefinition(query);
            var queryIterator = _container.GetItemQueryIterator<T>(queryDefinition);
            List<T> results = new List<T>();
            while (queryIterator.HasMoreResults)
            {
                FeedResponse<T> response = await queryIterator.ReadNextAsync();
                results.AddRange(response.ToList());
            }
            return results;
        }

        public async Task<bool> AddItemAsync<T>(string containerName, T item)
        {
            bool success = false;
            Container _container = _dbClient.GetContainer(_database, containerName);
            try
            {
                await _container.CreateItemAsync(item);
                success = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Adding item to the database:: container: {containerName} - {ex.Message}");
            }
            return success;
        }

        public async Task<bool> AddItemsAsync<T>(string containerName, string id,  List<T> items)
        {
            bool success = false;
            Container container = _dbClient.GetContainer(_database, containerName);
            List<Task> tasks = new List<Task>();

            foreach (var item in items) tasks.Add(container.CreateItemAsync(item, new PartitionKey(id)));

            try
            {
                await Task.WhenAll(tasks);
                success = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Adding items (bulk) to the database:: container: {containerName} - {ex.Message}");
            }
            return success;
        }

        public async Task<bool> UpdateItemAsync<T>(string containerName, string id, T item)
        {
            bool success = false;
            Container _container = _dbClient.GetContainer(_database, containerName);
            try
            {
                await _container.UpsertItemAsync(item, new PartitionKey(id));
                success = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Updating item in the database:: container: {containerName}:: id: {id} - {ex.Message}");
            }

            return success;
        }

        public async Task<bool> DeleteItemAsync<T>(string containerName, string id, string partitionKey)
        {
            bool success = false;
            Container _container = _dbClient.GetContainer(_database, containerName);
            try
            {
                await _container.DeleteItemAsync<T>(id, new PartitionKey(partitionKey));
                success = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Deleting item from database:: container: {containerName}:: id: {id} - {ex.Message}");
            }
            return success;
        }
    }
}
