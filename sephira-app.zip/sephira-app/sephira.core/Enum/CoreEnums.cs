﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.core.Enum
{
    public enum CoreRunStatus
    {
        Init = 0,
        Progress = 1,
        Pending = 2,
        Done = 3,
        Hold = 4,
        ToDo = 5
    }

    public enum CoreRunTypes { 
        Run = 0,
        Scenario = 1,
        Report = 2,
        Step = 3,
        Interaction = 4,
        Data = 5
    }

    public enum CoreRunRoles {
        System = 0,
        Assistant = 1,
        User = 2
    }

    public enum CoreRunStepRenderTypes
    {
        Text = 0,
        Title = 1,
        View = 2,
        Radio = 3,
        Checkbox = 4,
        RichText = 5,
        None = 6,
        JSON = 7,
    }

    public enum CoreRunStepActions
    {
        Show = 0,
        Confirm = 1,
        Next = 2,
        Select = 3,
        Input = 4,
        Complete = 5,
    }
}
