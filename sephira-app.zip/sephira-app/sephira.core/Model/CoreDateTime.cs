﻿
namespace sephira.core.Model
{
    public static class CoreDateTime
    {
        public static DateTime Now { get; private set; } = DateTime.UtcNow;
        public static string NowString { get; private set; } = DateTime.UtcNow.ToString();
    }
}
