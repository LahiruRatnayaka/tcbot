﻿
using System.Text.Json.Serialization;

namespace sephira.app.Models.Common.ReqModule
{
    public record StandardReq
    {
        [JsonPropertyName("objective")]
        public string Objective { get; set; }
        [JsonPropertyName("description")]
        public string Description { get; set; }
        [JsonPropertyName("functionalReq")]
        public List<string> FunctionalReq { get; set; }
    }
}
