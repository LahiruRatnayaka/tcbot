﻿using System.ComponentModel.DataAnnotations;

namespace sephira.app.Models.Common.Llm
{
    public class LlmConfig
    {
        // public string DeploymentName { get; set; }
        public float Temparature { get; set; } = 0.5F;
        public int P { get; set; } = 1;
        public bool enableJsonOutput { get; set; } = false;
    }
}
