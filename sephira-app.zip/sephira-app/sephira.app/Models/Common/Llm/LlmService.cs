﻿using sephira.app.Models.Common.Llm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Common.Llm
{
    public abstract class LlmService 
    {
        public virtual string Endpoint { get; set; } = "";
        public virtual string ApiKey { get; set; } = "";

        public LlmConfig _config { get; private set; }
        public List<LlmMessage> _messages { get; private set; }

        protected LlmService(LlmConfig config, List<LlmMessage> messages)
        {
            _config = config;
            _messages = messages;
        }

        public virtual string ExecuteAsync() {
            return "implement execute async method here";
        }
    }
}
