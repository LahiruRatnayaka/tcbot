﻿
using sephira.app.Enums;

namespace sephira.app.Models.Common.Llm
{
    public class LlmMessage
    {
        public LlmRole Role { get; set; } = LlmRole.USER;
        public string Content { get; set; } = "";
    }
}
