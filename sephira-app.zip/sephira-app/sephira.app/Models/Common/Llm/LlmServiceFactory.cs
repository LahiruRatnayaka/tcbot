﻿using sephira.app.Enums;
using sephira.app.Models.Common.Llm;

namespace sephira.app.Models.Common.Llm
{
    public abstract class LlmServiceFactory
    {

        public virtual string apiVersion { get; set; }

        public virtual string modelFamily { get; set; }

        protected abstract LlmService ProcessService(LlmConfig config, List<LlmMessage> messages);

        public LlmService Process(LlmConfig config, List<LlmMessage> messages)
        {
            return ProcessService(config, messages);
        }

        public static LlmServiceFactory getFactory(LlmModelProvider modelProvider)
        {
            LlmServiceFactory factory = null;

            switch (modelProvider)
            {
                case LlmModelProvider.OAGPT:
                    //factory = new OpenAiServiceFactory();
                    break;
                case LlmModelProvider.LLAMA:
                    break;
                case LlmModelProvider.OPUS:
                    break;
                case LlmModelProvider.MIXTRAL:
                    break;
                case LlmModelProvider.MISTAL:
                    break;
                default:
                    break;
            }
            return factory;
        }
    }
}
