﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Common.CodeRepo
{
    public class RepoFileContent
    {
        public string FileName { get; set; }
        public string Content { get; set; }
    }
}
