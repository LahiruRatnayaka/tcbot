﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Common
{
    public class ScenarioStep
    {
        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("vDependancy")]
        public List<string> VDependancy { get; set; }

        [JsonProperty("fDependancy")]
        public List<string> FDependancy { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("required")]
        public bool Required { get; set; }
    }

    public class ScenarioStepSimplified
    {
        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }
    }
}
