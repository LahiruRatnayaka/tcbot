﻿using Newtonsoft.Json;

namespace sephira.app.Models.Run.PayloadModels
{
    public class RunInitiatePayload
    {
        [JsonProperty("run")]
        public string Run { get; set; }

        [JsonProperty("scenarios")]
        public List<RunScenarioConfig> RunScenarioConfig { get; set; } = new List<RunScenarioConfig>();
    }

    public class RunScenarioConfig
    {
        [JsonProperty("scenarioId")]
        public string ScenarioId { get; set; }

        [JsonProperty("processConfig")]
        public List<RunProcessConfig> ProcessConfigs { get; set; } = new List<RunProcessConfig>();
    }

    public class RunProcessConfig
    {
        [JsonProperty("key")]
        public string Key { get; set; }
        [JsonProperty("val")]
        public string Value { get; set; }
    }
}
