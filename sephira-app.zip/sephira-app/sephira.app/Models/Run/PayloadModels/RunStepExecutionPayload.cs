﻿using Newtonsoft.Json;
using sephira.app.Models.Scenario;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Run.PayloadModels
{
    public class RunStepExecutionPayload
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("input")]
        public string Input { get; set; }

        [JsonProperty("type")]
        public string? Type { get; set; }

        [JsonProperty("action")]
        public string Action { get; set; }

    }
}
