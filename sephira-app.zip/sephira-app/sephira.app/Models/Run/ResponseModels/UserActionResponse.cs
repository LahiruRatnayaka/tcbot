﻿using Newtonsoft.Json;

namespace sephira.app.Models.Run.ResponseModels
{
    public class UserActionResponse
    {
        [JsonProperty("role ")]
        public string Role { get; set; } // assistan || user || sys

        [JsonProperty("renderType")]
        public string RenderType { get; set; } // input || radio || view || title || checkbox || richText || JSON

        [JsonProperty("subRenderType")]
        public string SubRenderType { get; set; } = string.Empty; // a custom type

        [JsonProperty("inputKey")]
        public string InputKey { get; set; } // key to identify which value to update

        [JsonProperty("inputValue")]
        public string InputValue { get; set; }

        [JsonProperty("action")]
        public string Action { get; set; } // view || confirm // next

        [JsonProperty("refData")]
        public string RefData { get; set; }

        [JsonProperty("content")]
        public string Content { get; set; } = string.Empty;

        [JsonProperty("nextStepId")]
        public string NextStepId { get; set; }

       
    }
}
