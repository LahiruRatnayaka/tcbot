﻿using Newtonsoft.Json;
using sephira.core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Run.ResponseModels
{
    public class RunInteractionResponse
    {
        [JsonProperty("role")]
        public string Role { get; set; }

        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("subType")]
        public string SubType { get; set; }

        [JsonProperty("data")]
        public string Data { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("nextStepId")]
        public string NextStepId { get; set; }

        [JsonProperty("ts")]
        public DateTime Ts { get; set; }
    }
}
