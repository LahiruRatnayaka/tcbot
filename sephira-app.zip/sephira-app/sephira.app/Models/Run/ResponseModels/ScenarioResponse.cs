﻿using Newtonsoft.Json;

namespace sephira.app.Models.Run.ResponseModels
{
    public class ScenarioResponse
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("scenarios")]
        public List<ScenarioItem> Scenarios { get; set; } = new List<ScenarioItem>();
    }

    public class ScenarioItem
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("Seq")]
        public int Seq { get; set; }
    }
}
