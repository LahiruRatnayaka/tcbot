﻿using Newtonsoft.Json;

namespace sephira.app.Models.Run.ResponseModels
{
    public class ScenarioStepsResponse
    {
        public List<ScenarioStepReqItem> ScenariosSteps { get; set; } = new List<ScenarioStepReqItem>();
    }
    public class ScenarioStepReqItem
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }
    }
}
