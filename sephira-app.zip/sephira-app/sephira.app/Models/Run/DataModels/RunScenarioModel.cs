﻿using Azure.Data.Tables;
using Azure;
using Newtonsoft.Json;
using sephira.app.Models.Common;
using sephira.core.Enum;
using sephira.core.Model;

namespace sephira.app.Models.Run.DataModels
{
    internal class RunScenarioModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("version")]
        public string version { get; set; } = "2024-06-01-preview";

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; } = CoreRunTypes.Scenario.ToString();

        [JsonProperty("run")]
        public BaseRunModel Run { get; set; }

        [JsonProperty("scenario")]
        public BaseScenarioModel Scenario { get; set; }

        [JsonProperty("steps")]
        public List<ScenarioStepSimplified> Steps { get; set; } = new List<ScenarioStepSimplified>();

        [JsonProperty("status")]
        public string Status { get; set; } = CoreRunStatus.ToDo.ToString();

        [JsonProperty("reportRef")]
        public string ReportRef { get; set; }

        [JsonProperty("_cts")]
        public DateTime Cts { get; set; } = CoreDateTime.Now;

        [JsonProperty("_uts")]
        public DateTime Uts { get; set; }
    }

    // table storage
    public class TRunScenarioModel : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public string Data { get; set; }
    }
}
