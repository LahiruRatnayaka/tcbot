﻿using Azure.Data.Tables;
using Azure;
using Newtonsoft.Json;
using sephira.core.Enum;
using sephira.core.Model;

namespace sephira.app.Models.Run.DataModels
{
    internal class RunScenarioStepModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("version")]
        public string version { get; set; } = "2024-06-01-preview";

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("totalSeqCount")]
        public int TotalSeqCount { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; } = CoreRunTypes.Step.ToString();

        [JsonProperty("run")]
        public BaseRunModel Run { get; set; }

        [JsonProperty("scenario")]
        public BaseScenarioModel Scenario { get; set; }

        [JsonProperty("vDependancy")]
        public List<VDependancy> VDependancy { get; set; } = new List<VDependancy>();

        [JsonProperty("fDependancy")]
        public List<FDependancy> FDependancy { get; set; } = new List<FDependancy>();

        [JsonProperty("dataRef")]
        public string DataRef { get; set; }

        [JsonProperty("nextStep")]
        public string NextStepId { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; } = CoreRunStatus.ToDo.ToString();

        [JsonProperty("_cts")]
        public DateTime Cts { get; private set; } = CoreDateTime.Now;

        [JsonProperty("_uts")]
        public DateTime Uts { get; set; }
    }

    internal class VDependancy
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }

        [JsonProperty("filled")]
        public bool Filled { get; set; }

        [JsonProperty("input")]
        public string Input { get; set; }
    }

    internal class FDependancy
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("retrieved")]
        public bool Retrieved { get; set; }
    }


    // ITable Storage Implementation

    public class TRunScenarioStepModel : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public string Data { get; set; }
        public string Code { get; set; }
    }
}
