﻿using Azure.Data.Tables;
using Azure;
using Newtonsoft.Json;
using sephira.core.Model;

namespace sephira.app.Models.Run.DataModels
{
    internal class ScenarioInteractionModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("subType")]
        public string SubType { get; set; }

        [JsonProperty("run")]
        public BaseRunModel Run { get; set; }

        [JsonProperty("scenario")]
        public BaseScenarioModel Scenario { get; set; }

        [JsonProperty("interactions")]
        public List<RunInteraction> Interactions { get; set; } = new List<RunInteraction>();

        [JsonProperty("_cts")]
        public DateTime Cts { get; set; } = CoreDateTime.Now;

        [JsonProperty("_uts")]
        public DateTime Uts { get; set; }
    }


    // table storage
    public class TScenarioInteractionModel : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public string Data { get; set; }
    }


}
