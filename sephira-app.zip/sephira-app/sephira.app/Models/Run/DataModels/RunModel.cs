﻿using Azure.Data.Tables;
using Azure;
using Newtonsoft.Json;
using sephira.core.Enum;
using sephira.core.Model;

namespace sephira.app.Models.Run.DataModels
{
    internal class RunModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("version")]
        public string version { get; set; } = "2024-06-01-preview";

        [JsonProperty("name")]
        public string Name { get; set; } 

        [JsonProperty("type")]
        public string Type { get; set; } = CoreRunTypes.Run.ToString();

        [JsonProperty("run")]
        public BaseRunModel Run { get; set; }

        [JsonProperty("scenarios")]
        public int Scenarios { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; } = CoreRunStatus.Init.ToString();

        [JsonProperty("_cts")]
        public DateTime Cts { get; set; } = CoreDateTime.Now;

        [JsonProperty("_uts")]
        public DateTime Uts { get; set; } 
    }

    // table storage
    public class TRunModel : ITableEntity
    {
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public string Data { get; set; }
    }

}
