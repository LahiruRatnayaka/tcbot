﻿using Newtonsoft.Json;
using sephira.core.Model;
using System.Security.Cryptography.X509Certificates;

namespace sephira.app.Models.Run.DataModels
{
    internal class BaseRunModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }

    internal class BaseScenarioModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("seq")]
        public int Seq { get; set; }
    }

    internal class StepDependancyItem {
        public string Key { get; set; }
        public string Value { get; set; }
    }

    internal class RunInteraction
    {
        [JsonProperty("role")]
        public string Role { get; set; }

        [JsonProperty("seq")]
        public int Seq { get; set; }

        [JsonProperty("type")]
        public string Type { get; set; }

        [JsonProperty("subType")]
        public string SubType { get; set; }

        [JsonProperty("data")]
        public string Data { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("ts")]
        public DateTime Ts { get; set; } = CoreDateTime.Now;
    }
}
