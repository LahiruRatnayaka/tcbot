﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Business
{
    public class BusinessTestExecutionPlanModel
    {
        [JsonProperty("executionPlans")]
        public List<TestExecutionPlan> ExecutionPlans { get; set; }
    }

    public class TestExecutionPlan
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("path")]
        public string Path { get; set; }

        [JsonProperty("method")]
        public string Method { get; set; }

        [JsonProperty("headers")]
        public List<Header> Headers { get; set; }

        [JsonProperty("requestBody")]
        public string RequestBody { get; set; }

        [JsonProperty("expectedResponse")]
        public ExpectedResponse ExpectedResponse { get; set; }
    }

    public class ExpectedResponse
    {
        [JsonProperty("statusCode")]
        public int StatusCode { get; set; }

        [JsonProperty("responseBody")]
        public object ResponseBody { get; set; }
    }

    public class Header
    {
        [JsonProperty("key")]
        public string Key { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }
    }

}
