﻿using sephira.app.Interfaces;
using System.Text;


namespace sephira.app.Models.Business
{
    public class BusinessTestExecutionService : ITestExecutionService
    {
        public async Task<List<BusinessTestExecutionResult>> executeTestScenario(string baseUrl, BusinessTestExecutionPlanModel businessPlan)
        {
            var results = new List<BusinessTestExecutionResult>();
            using var httpClient = new HttpClient();

            foreach (var plan in businessPlan.ExecutionPlans)
            {
                string url = baseUrl + plan.Path;
                var result = new BusinessTestExecutionResult { Url = url };
                try
                {
                    HttpRequestMessage requestMessage = new HttpRequestMessage
                    {
                        RequestUri = new Uri(url),
                        Method = new HttpMethod(plan.Method)
                    };

                    if (plan.Headers != null)
                    {
                        foreach (var header in plan.Headers)
                        {
                            requestMessage.Headers.Add(header.Key, header.Value);
                        }
                    }

                    if (!string.IsNullOrEmpty(plan.RequestBody))
                    {
                        requestMessage.Content = new StringContent(plan.RequestBody, Encoding.UTF8, "application/json");
                    }

                    HttpResponseMessage response = await httpClient.SendAsync(requestMessage);
                    string responseContent = await response.Content.ReadAsStringAsync();

                    result.Response = responseContent;
                    result.IsSuccess = responseContent ==  plan.ExpectedResponse.ResponseBody;
                }
                catch (Exception ex)
                {
                    result.IsSuccess = false;
                    result.Error = ex.Message;
                }

                results.Add(result);
            }

            return results;
        }
    }
}
