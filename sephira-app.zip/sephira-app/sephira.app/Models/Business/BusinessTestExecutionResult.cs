﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Business
{
    public class BusinessTestExecutionResult
    {
        public string Url { get; set; }
        public bool IsSuccess { get; set; }
        public string Response { get; set; }
        public string Error { get; set; }
    }
}
