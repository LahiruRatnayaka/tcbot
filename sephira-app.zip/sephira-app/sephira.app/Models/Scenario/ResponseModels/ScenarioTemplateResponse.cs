﻿using Newtonsoft.Json;
using sephira.app.Models.Scenario.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Models.Scenario.ResponseModels
{
    public class ScenarioTemplateResponse
    {
        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("scenarios")]
        public List<ScenarioModel> scenarios { get; set; } = new List<ScenarioModel>();
    }
}
