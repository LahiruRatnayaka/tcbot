﻿using Azure;
using Azure.Data.Tables;
using Newtonsoft.Json;
using sephira.app.Models.Common;

namespace sephira.app.Models.Scenario.DataModels
{
    public class ScenarioModel
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("version")]
        public string version { get; set; } = "2024-06-01-preview";

        [JsonProperty("scenario")]
        public Scenario Scenario { get; set; }

        [JsonProperty("description")]
        public Description Description { get; set; }

        [JsonProperty("preRequisities")]
        public List<PreRequisity> PreRequisities { get; set; }

        [JsonProperty("steps")]
        public List<ScenarioStep> Steps { get; set; }

        [JsonProperty("_cts")]
        public DateTime Cts { get; set; }

        [JsonProperty("_uts")]
        public DateTime Uts { get; set; }

        [JsonProperty("_rid")]
        public string Rid { get; set; }

        [JsonProperty("_self")]
        public string Self { get; set; }

        [JsonProperty("_etag")]
        public string Etag { get; set; }

        [JsonProperty("_attachments")]
        public string Attachments { get; set; }

        [JsonProperty("_ts")]
        public int Ts { get; set; }
    }

    public class Description
    {
        [JsonProperty("short")]
        public string Short { get; set; }

        [JsonProperty("long")]
        public string Long { get; set; }
    }

    public class PreRequisity
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("options")]
        public List<PreRequisityOptions> Options { get; set; } = new List<PreRequisityOptions>();

        [JsonProperty("actionalble")]
        public bool Actionalble { get; set; }

        [JsonProperty("label")]
        public string Label { get; set; }

        [JsonProperty("required")]
        public bool Required { get; set; }

        [JsonProperty("userSelection")]
        public List<string> UserSelection { get; set; }
    }

    public class PreRequisityOptions
    {
        [JsonProperty("icon")]
        public string Icon { get; set; }

        [JsonProperty("label")]
        public string Label { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }
    }

    public class Scenario
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("categoryName")]
        public string CategoryName { get; set; }
    }

    public class ScenarioCategory
    {
        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("scenarios")]
        public IEnumerable<ScenarioModel> Scenarios { get; set; }
    }

    // ITable Storage Implementation

    public class TScenarioModel : ITableEntity
    {
        public string PartitionKey { get ; set ; }
        public string RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        public string Data { get; set; }
    }

}
