﻿using sephira.app.Models.Common;
using sephira.app.Models.Scenario;
using sephira.app.Models.Scenario.DataModels;
using sephira.app.Models.Scenario.ResponseModels;

namespace sephira.app.Interfaces
{
    public interface IScenarioService
    {
        Task<Response<List<ScenarioTemplateResponse>>> GetScenarioTemplates();

        Task<ScenarioModel> GetScenarioTemplate(string templateId);
    }
}
