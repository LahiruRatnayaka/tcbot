﻿using sephira.app.Models.Common.Llm;

namespace sephira.app.Interfaces
{
    public interface ILlmService
    {
        string Execute(LlmConfig config, List<LlmMessage> messages);
    }
}
