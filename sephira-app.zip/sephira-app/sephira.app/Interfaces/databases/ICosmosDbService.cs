﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Interfaces.databases
{
    public interface ICosmosDbService
    {
        Task<T> GetItemAsync<T>(string containerName, string id, string partitionKey);
        Task<IEnumerable<T>> GetItemsAsync<T>(string containerName, string query);
        Task<bool> AddItemAsync<T>(string containerName, T item);
        Task<bool> AddItemsAsync<T>(string containerName, string id, List<T> items);
        Task<bool> UpdateItemAsync<T>(string containerName, string id, T item);
        Task<bool> DeleteItemAsync<T>(string containerName, string id, string partitionKey);
    }
}
