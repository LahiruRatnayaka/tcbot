﻿using Azure.Data.Tables;

namespace sephira.app.Interfaces.databases
{
    public interface ITableStorageService
    {
        Task<T> GetItemAsync<T>(string tableName, string partitionKey, string rowKey) where T : class, ITableEntity, new();
        Task<List<T>> GetItemsAsync<T>(string tableName) where T : class, ITableEntity, new();
        Task<bool> AddItemAsync<T>(string tableName, T item) where T : class, ITableEntity;
        Task<bool> UpdateItemAsync<T>(string tableName, T item) where T : class, ITableEntity;
        Task<bool> AddItemsAsync<T>(string tableName, List<T> items) where T : class, ITableEntity;
        Task<List<T>> GetItemByQueryAsync<T>(string tableName, string partitionKey) where T : class, ITableEntity, new();
        Task<List<T>> GetItemsByFilterAsync<T>(string tableName, string filterQuery) where T : class, ITableEntity, new();
        Task DeleteItemAsync(string tableName, string partitionKey, string rowKey);
    }
}
