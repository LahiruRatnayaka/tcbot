﻿using sephira.app.Models.Common;
using sephira.app.Models.Run.PayloadModels;
using sephira.app.Models.Run.ResponseModels;

namespace sephira.app.Interfaces
{
    public interface IRunServices 
    {
        Task<Response<string>> InitiateRun(RunInitiatePayload payload);

        Task<Response<ScenarioResponse>> GeRunningScenarios(string runId);

        Task<Response<ScenarioStepsResponse>> GetRunningScenarioSteps(string runId, int scenarioSeq);

        Task<Response<UserActionResponse>> ExecuteScenarioStep(string runId, int scenarioSeq, int stepSeq, RunStepExecutionPayload payload);

        Task<Response<List<RunInteractionResponse>>> GetRunScenarioInteractions(string runId, int scenarioSeq);
    }
}
