﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Interfaces
{
    public interface IHttpRequestExecutor
    {
        Task<string> ExecuteRequestAsync(string url, HttpMethod method, HttpContent content = null, IDictionary<string, string> headers = null);
    }
}
