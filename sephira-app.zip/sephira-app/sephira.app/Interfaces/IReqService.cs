﻿using sephira.app.Models.Common.ReqModule;

namespace sephira.app.Interfaces
{
    public interface IReqService
    {
        string getHumanToneReponse(string ask);

        string Enhance(string requirement);

        string GenerateBusinessTestPlan(string enhancedRequrement);

        string EnhanceSwaggerDocument(string existSpecification, string codeContent);

        string GenerateTestExecutionPlan(string existSpecification, string testPlan, string codeRepo);

        string CompareTestExecutionResults(string executionPlan, string invokeResult);
    }
}
