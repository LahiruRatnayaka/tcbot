﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Interfaces
{
    public interface IRepoService
    {
        string GetRepoFileContent(string source, string type, string framework);
    }
}
