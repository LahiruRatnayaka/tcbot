﻿using sephira.app.Models.Common.ReqModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Interfaces
{
    public interface ISwaggerService
    {
        Task<string> Enhance(string repoCloneUrl, string swaggerUrl);

        Task<string> Get(string url);

    }
}
