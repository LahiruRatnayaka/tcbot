﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Interfaces
{
    public interface IRepoConnector
    {
        /// <summary>
        /// Clone any repository to a pre-defined local path.
        /// 
        /// local path should declare in the implementation.
        /// eg. c:/temp/sephira/github/{uniqueNumber}
        /// </summary>
        /// <param name="cloneUrl">Clone url of the repository</param>
        /// <returns>local path</returns>
        string CloneRepo(string cloneUrl); 
    }
}
