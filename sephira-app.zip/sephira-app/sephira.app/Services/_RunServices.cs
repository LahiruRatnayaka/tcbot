﻿using Microsoft.Extensions.Logging;

// core
using sephira.core.Enum;
using sephira.core.Model;

// app
using sephira.app.Interfaces;
using sephira.app.Interfaces.databases;
using sephira.app.Models.Run.DataModels;
using sephira.app.Models.Run.PayloadModels;
using sephira.app.Models.Run.ResponseModels;
using sephira.app.Models.Common;
using sephira.app.Models.Business;
using System.Text.Json.Nodes;
using Newtonsoft.Json;

namespace sephira.app.Services
{
    /// <summary>
    /// A class that handle all the required functions and services to run a collection of scenarios
    /// for a single run by executing each step of each scenario.
    /// 
    /// Terminology:
    /// 
    ///     Run     - A collection of user selected test scenarios to run at one go. Run could consist of
    ///               multiple scenarios.
    ///     Scenario- An independant test scenario such as unit test, integration test, etc.
    ///     Step    - A single component among many to construct the whole scenario. Scenario could have
    ///               multiple steps.
    ///     
    /// 
    /// </summary>
    public class _RunServices // : IRunServices
    {
        private readonly ILogger<_RunServices> _logger;
        private readonly IReqService _reqService;
        private readonly ICosmosDbService _cosmosDbService;
        private readonly ISwaggerService _swaggerService;
        private readonly IRepoService _repoService;
        private readonly IScenarioService _scenarioService;

        private string runContainer { get; set; } = "run";

        public _RunServices(
            ILogger<_RunServices> logger,
            IReqService reqService,
            ICosmosDbService cosmosDbService,
            ISwaggerService swaggerService,
            IRepoService repoService,
            IScenarioService scenarioService
            )
        {
            _logger = logger;

            _reqService = reqService;
            _cosmosDbService = cosmosDbService;
            _swaggerService = swaggerService;
            _repoService = repoService;
            _scenarioService = scenarioService;
        }

        public async Task<Response<string>> InitiateRun(RunInitiatePayload payload)
        {
            List<bool> successess = new List<bool>();
            int successScenarioCount = 0;
            Response<string> response = new Response<string>();

            if (payload.RunScenarioConfig.Count <= 0)
            {
                response.Error = new ErrorResponse()
                {
                    Code = 404,
                    Message = "No scenarios to run"
                };
            }

            BaseRunModel baseRunModel = new BaseRunModel
            {
                Id = Guid.NewGuid().ToString(),
                Name = payload.Run
            };

            for (int i = 0; i < payload.RunScenarioConfig.Count; i++)
            {
                RunScenarioConfig scenarioConfig = payload.RunScenarioConfig[i];

                Models.Scenario.DataModels.ScenarioModel scenarioTemplate = await _scenarioService.GetScenarioTemplate(scenarioConfig.ScenarioId);
                if (scenarioTemplate == null) break;

                BaseScenarioModel baseScenarioModel = new BaseScenarioModel
                {
                    Id = $"rs{(i + 1)}-{baseRunModel.Id}",
                    Name = scenarioTemplate.Scenario.Name,
                    Seq = (i + 1),
                };

                List<ScenarioStep> scenarioSteps = new List<ScenarioStep>();
                if (scenarioTemplate.Steps.Count > 0)
                {
                    scenarioSteps = scenarioTemplate.Steps.Select(x => new ScenarioStep
                    {
                        Seq = x.Seq,
                        Code = x.Code,
                        Title = x.Title,
                        FDependancy = x.FDependancy,
                        VDependancy = x.VDependancy,
                        Status = x.Status,
                        Required = x.Required
                    }).ToList();
                    successess.Add(await CreateScenarioSteps(baseRunModel, baseScenarioModel, scenarioSteps, payload.RunScenarioConfig[i].ProcessConfigs));
                }

                // Scenario
                successess.Add(await CreateSenario(baseRunModel, baseScenarioModel, scenarioSteps));

                // Interactions
                successess.Add(await CreateInteraction(baseRunModel, baseScenarioModel));

                // Reports
                successess.Add(await CreateReport(baseRunModel, baseScenarioModel));

                successScenarioCount++;
            }

            // Create Run
            successess.Add(await CreateRun(baseRunModel, successScenarioCount));

            if (successess.Any(x => x == false))
            {
                response.Error = new ErrorResponse
                {
                    Code = 500,
                    Message = "Run initiate process failes"
                };
            }
            else
            {
                response.Data = $"{{ \"id\" : \"{baseRunModel.Id}\" }}";
            }
            return response;
        }
        public async Task<Response<ScenarioResponse>> GeRunningScenarios(string runId)
        {
            Response<ScenarioResponse> response = new Response<ScenarioResponse>();

            RunModel? runModel = await GetRun(runId);
            if (runModel == null)
            {
                response.Error = new ErrorResponse
                {
                    Code = 404,
                    Message = "Running instance not found"
                };
                return response;
            }

            List<RunScenarioModel> scenarios = await GetScenariosForRunId(runId);
            if (scenarios.Count <= 0)
            {
                response.Error = new ErrorResponse
                {
                    Code = 404,
                    Message = "No scenarios found"
                };
                return response;
            }

            ScenarioResponse scenarioResponseModel = new ScenarioResponse
            {
                Name = runModel.Name,
                Id = runModel.Id,
                Scenarios = scenarios.Select(x => new ScenarioItem
                {
                    Id = x.Id,
                    Name = x.Name,
                    Status = x.Status,
                    Seq = x.Seq
                }).ToList(),
            };

            response.Data = scenarioResponseModel;
            return response;
        }
        public async Task<Response<ScenarioStepsResponse>> GetRunningScenarioSteps(string runId, int scenarioSeq)
        {
            Response<ScenarioStepsResponse> response = new Response<ScenarioStepsResponse>();
            ScenarioStepsResponse scenarioStepsReqResponseModel = new ScenarioStepsResponse();

            List<RunScenarioStepModel> runScenarioSteps = await GetScenarioStepsForRunId(runId, scenarioSeq);

            scenarioStepsReqResponseModel.ScenariosSteps = runScenarioSteps.Select(x => new ScenarioStepReqItem
            {
                Id = x.Id,
                Name = x.Name,
                Status = x.Status,
                Seq = x.Seq,
                Code = x.Code

            }).OrderBy(x => x.Seq).ToList();

            response.Data = scenarioStepsReqResponseModel;

            return response;
        }
        public async Task<Response<UserActionResponse>> ExecuteScenarioStep(string runId, int scenarioSeq, int stepSeq, RunStepExecutionPayload payload)
        {
            Response<UserActionResponse> response = new Response<UserActionResponse>();
            UserActionResponse execution = new UserActionResponse();

            string scenarioId = GenerateScenarioId(runId, scenarioSeq);
            string stepId = GenerateStepId(scenarioId, stepSeq);

            var stepToExecute = await GetScenarioStep(scenarioId, stepSeq);
            if (stepToExecute == null)
            {
                response.Error = new ErrorResponse
                {
                    Code = 404,
                    Message = "Step not found"
                };
                return response;
            }
            CoreRunStatus stepStatus = (CoreRunStatus)Enum.Parse(typeof(CoreRunStatus), stepToExecute.Status);

            switch (stepStatus)
            {
                case CoreRunStatus.ToDo:
                    string sectionTitle = $"[{stepToExecute.Seq}/{stepToExecute.TotalSeqCount}] - {stepToExecute.Name}";
                    var section = CreateInteraction(CoreRunRoles.Assistant.ToString(), "SYS", CoreRunStepRenderTypes.Title.ToString(), sectionTitle, stepToExecute.Code, string.Empty);
                    await AddInteration(stepToExecute.Run, stepToExecute.Scenario.Seq, section);

                    execution = await PreRequistiesHandler(stepToExecute);
                    stepToExecute.Status = CoreRunStatus.Pending.ToString();
                    break;
                case CoreRunStatus.Pending:
                    CoreRunStepActions action = (CoreRunStepActions)Enum.Parse(typeof(CoreRunStepActions), payload.Action);

                    // JSON should process diferently for interactions as well.
                    CoreRunStepRenderTypes type = payload.Type == "JSON" ? CoreRunStepRenderTypes.JSON : CoreRunStepRenderTypes.View;
                    string subType = type == CoreRunStepRenderTypes.JSON ? stepToExecute.Code : string.Empty;

                    switch (action)
                    {
                        case CoreRunStepActions.Input:
                            var userInput = CreateInteraction(CoreRunRoles.User.ToString(), "SYS", type.ToString(), payload.Input, stepToExecute.Code, subType);
                            await AddInteration(stepToExecute.Run, stepToExecute.Scenario.Seq, userInput);

                            // should update the step filed with input data
                            var valueDependancy = stepToExecute.VDependancy.Where(x => x.Key == payload.Key).FirstOrDefault();
                            if (valueDependancy != null)
                            {
                                valueDependancy.Input = payload.Input;
                                valueDependancy.Filled = true;
                                await _cosmosDbService.UpdateItemAsync(runContainer, runId, stepToExecute);
                            }
                            // To Refactor above

                            execution = await PreRequistiesHandler(stepToExecute, true);
                            if (execution == null)
                            {
                                execution = new UserActionResponse()
                                {
                                    Role = CoreRunRoles.System.ToString(),
                                    RenderType = CoreRunStepRenderTypes.None.ToString(),
                                    Action = CoreRunStepActions.Next.ToString(),
                                    NextStepId = stepToExecute.NextStepId == "NA" ? stepId : stepToExecute.NextStepId
                                };
                            }

                            if (!string.IsNullOrEmpty(execution.Content))
                            {
                                stepToExecute.DataRef = execution.Content;
                                execution.Content = string.Empty;
                            }
                            break;
                        case CoreRunStepActions.Confirm:
                            stepToExecute.DataRef = payload.Input;
                            execution = new UserActionResponse()
                            {
                                Role = CoreRunRoles.System.ToString(),
                                RenderType = CoreRunStepRenderTypes.None.ToString(),
                                Action = CoreRunStepActions.Next.ToString(),
                                NextStepId = stepToExecute.NextStepId == "NA" ? stepId : stepToExecute.NextStepId
                            };

                            var confirmDataRef = CreateInteraction(CoreRunRoles.Assistant.ToString(), "SYS", type.ToString(), payload.Input, stepToExecute.Code, subType);
                            await AddInteration(stepToExecute.Run, stepToExecute.Scenario.Seq, confirmDataRef);

                            stepToExecute.Status = CoreRunStatus.Done.ToString();
                            break;
                        case CoreRunStepActions.Complete:
                            execution = new UserActionResponse()
                            {
                                Role = CoreRunRoles.System.ToString(),
                                RenderType = CoreRunStepRenderTypes.None.ToString(),
                                Action = CoreRunStepActions.Next.ToString(),
                                NextStepId = stepToExecute.NextStepId == "NA" ? stepId : stepToExecute.NextStepId
                            };

                            var confirmInteraction = CreateInteraction(CoreRunRoles.Assistant.ToString(), "SYS", type.ToString(), payload.Input, stepToExecute.Code, subType);
                            await AddInteration(stepToExecute.Run, stepToExecute.Scenario.Seq, confirmInteraction);

                            if (stepToExecute.NextStepId == "NA")
                            {

                                var endOfExecutionNote = CreateInteraction(CoreRunRoles.Assistant.ToString(), "SYS", CoreRunStepRenderTypes.View.ToString(), "--- End of Execution ---", stepToExecute.Code, subType);
                                await AddInteration(stepToExecute.Run, stepToExecute.Scenario.Seq, endOfExecutionNote);
                            }

                            stepToExecute.Status = CoreRunStatus.Done.ToString();
                            break;
                        default:
                            execution = await PreRequistiesHandler(stepToExecute);
                            break;
                    }
                    break;
                case CoreRunStatus.Done:
                    execution = new UserActionResponse()
                    {
                        Role = CoreRunRoles.System.ToString(),
                        RenderType = CoreRunStepRenderTypes.None.ToString(),
                        Action = CoreRunStepActions.Next.ToString(),
                        NextStepId = stepToExecute.NextStepId == "NA" ? stepId : stepToExecute.NextStepId
                    };
                    break;
                default:
                    break;
            }

            await UpdateScenarioStep(stepToExecute);
            response.Data = execution;
            return response;
        }

        #region Utilities
        private string GenerateScenarioId(string runId, int scenarioSeq) => $"rs{scenarioSeq}-{runId}";
        private string GenerateStepId(string scenarioId, int stepSeq) => $"re{stepSeq}-{scenarioId}";
        private RunInteraction CreateInteraction(string role, string key, string type, string data, string category, string subType)
        {
            return new RunInteraction()
            {
                Role = role,
                Type = type,
                SubType = subType,
                Data = data,
                Status = CoreRunStatus.Done.ToString(),
                Key = key,
                Category = category,
                Ts = CoreDateTime.Now
            };
        }

        // Initiate
        private async Task<bool> CreateRun(BaseRunModel baseRunModel, int scenarioCount)
        {
            RunModel runModel = new RunModel
            {
                Id = baseRunModel.Id,
                Name = baseRunModel.Name,
                Type = CoreRunTypes.Run.ToString(),
                Run = baseRunModel,
                Scenarios = scenarioCount,
                Status = CoreRunStatus.Init.ToString(),
                Uts = CoreDateTime.Now
            };
            return await _cosmosDbService.AddItemAsync<RunModel>(runContainer, runModel);
        }
        private async Task<bool> CreateSenario(BaseRunModel baseRunModel, BaseScenarioModel baseScenarioModel, List<ScenarioStep> scenarioSteps)
        {
            RunScenarioModel runScenarioModel = new RunScenarioModel
            {
                Id = baseScenarioModel.Id,
                Name = baseScenarioModel.Name,
                Seq = baseScenarioModel.Seq,
                Type = CoreRunTypes.Scenario.ToString(),
                Run = baseRunModel,
                Scenario = baseScenarioModel,
                Steps = scenarioSteps.Select(x => new ScenarioStepSimplified
                {
                    Code = x.Code,
                    Seq = x.Seq,
                    Title = x.Title
                }).ToList(),
                Status = CoreRunStatus.Init.ToString(),
                Uts = CoreDateTime.Now,
                ReportRef = $"rr-{baseScenarioModel.Id}"
            };
            return await _cosmosDbService.AddItemAsync(runContainer, runScenarioModel);
        }
        private async Task<bool> CreateScenarioSteps(BaseRunModel baseRunModel, BaseScenarioModel baseScenarioModel, List<ScenarioStep> scenarioSteps, List<RunProcessConfig> processConfig)
        {
            List<RunScenarioStepModel> stepsToInsert = new List<RunScenarioStepModel>();

            for (int i = 0; i < scenarioSteps.Count; i++)
            {
                string stepId = GenerateStepId(baseScenarioModel.Id, (i + 1));
                ScenarioStep step = scenarioSteps[i];

                RunScenarioStepModel runStepModel = new RunScenarioStepModel
                {
                    Id = stepId,
                    Name = step.Title,
                    Seq = step.Seq,
                    TotalSeqCount = scenarioSteps.Count,
                    Code = step.Code,
                    Type = CoreRunTypes.Step.ToString(),
                    Run = baseRunModel,
                    Scenario = baseScenarioModel,
                    DataRef = $"rd-{stepId}",
                    NextStepId = (scenarioSteps.Count - 1) == i ? "NA" : GenerateStepId(baseScenarioModel.Id, (step.Seq + 1)),
                    FDependancy = step.FDependancy.Select(x => new FDependancy
                    {
                        Code = x,
                        Retrieved = false,

                    }).ToList(),
                    VDependancy = step.VDependancy.Select(x => new VDependancy
                    {
                        Key = x,
                        Value = processConfig.Where(y => y.Key == x).Select(y => y.Value).FirstOrDefault(),
                        Filled = false,
                        Input = string.Empty

                    }).ToList(),
                    Status = CoreRunStatus.ToDo.ToString(),
                    Uts = CoreDateTime.Now
                };

                stepsToInsert.Add(runStepModel);
            }
            return await _cosmosDbService.AddItemsAsync(runContainer, baseRunModel.Id, stepsToInsert);
        }
        private async Task<bool> CreateInteraction(BaseRunModel baseRunModel, BaseScenarioModel baseScenarioModel)
        {
            ScenarioInteractionModel runInteractionModel = new ScenarioInteractionModel
            {
                Id = $"ri-{baseScenarioModel.Id}",
                Name = baseScenarioModel.Name,
                Type = CoreRunTypes.Interaction.ToString(),
                Run = baseRunModel,
                Scenario = baseScenarioModel,
                Uts = CoreDateTime.Now
            };
            return await _cosmosDbService.AddItemAsync(runContainer, runInteractionModel);
        }
        private async Task<bool> CreateReport(BaseRunModel baseRunModel, BaseScenarioModel baseScenarioModel)
        {
            ScenarioReportModel runReportModel = new ScenarioReportModel
            {
                Id = $"rr-{baseScenarioModel.Id}",
                Name = baseScenarioModel.Name,
                Type = CoreRunTypes.Report.ToString(),
                Run = baseRunModel,
                Scenario = baseScenarioModel,
                Uts = CoreDateTime.Now
            };
            return await _cosmosDbService.AddItemAsync(runContainer, runReportModel);
        }

        // Run
        private async Task<List<RunScenarioModel>> GetScenariosForRunId(string runId)
        {

            string query = $"SELECT * FROM c WHERE c.run.id = '{runId}' AND c.type = 'Scenario'";
            var runScenarioRaw = await _cosmosDbService.GetItemsAsync<RunScenarioModel>(runContainer, query);

            if (runScenarioRaw == null) return new List<RunScenarioModel>();
            return runScenarioRaw.ToList();
        }
        private async Task<RunModel?> GetRun(string runId)
        {
            string query = $"SELECT * FROM c WHERE c.id = '{runId}' AND c.type = 'Run'";
            var runRaw = await _cosmosDbService.GetItemsAsync<RunModel>(runContainer, query);

            return runRaw.FirstOrDefault();
        }
        private async Task<List<RunScenarioStepModel>> GetScenarioStepsForRunId(string runId, int scenarioSeq)
        {
            string scenarioId = GenerateScenarioId(runId, scenarioSeq);
            string query = $"SELECT * FROM c WHERE c.run.id = '{runId}' AND c.scenario.id = '{scenarioId}' AND c.type = 'Step'";

            var runScenarioStepsRaw = await _cosmosDbService.GetItemsAsync<RunScenarioStepModel>(runContainer, query);

            if (runScenarioStepsRaw == null) return new List<RunScenarioStepModel>();
            return runScenarioStepsRaw.ToList();
        }
        private async Task<RunScenarioStepModel?> GetScenarioStep(string scenarioId, int stepSeq)
        {
            string stepId = GenerateStepId(scenarioId, stepSeq);
            string query = $"SELECT * FROM c WHERE c.scenario.id = '{scenarioId}' AND c.id = '{stepId}' AND c.type = 'Step'";

            var runStepsRaw = await _cosmosDbService.GetItemsAsync<RunScenarioStepModel>(runContainer, query);

            if (runStepsRaw == null) return null;
            return runStepsRaw.FirstOrDefault();
        }
        private async Task<bool> AddInteration(BaseRunModel baseRunModel, int scenarioSeq, RunInteraction interaction)
        {
            string scenarioId = GenerateScenarioId(baseRunModel.Id, scenarioSeq);
            string query = $"SELECT * FROM c WHERE c.run.id = '{baseRunModel.Id}' AND c.scenario.id = '{scenarioId}' AND c.type = 'Interaction'";
            var interactionsRaw = await _cosmosDbService.GetItemsAsync<ScenarioInteractionModel>(runContainer, query);
            ScenarioInteractionModel interactions = interactionsRaw.FirstOrDefault();

            if (interactions == null) return false;
            interaction.Seq = interactions.Interactions.Count + 1;

            interactions.Interactions.Add(interaction);
            return await _cosmosDbService.UpdateItemAsync(runContainer, baseRunModel.Id, interactions);
        }
        private async Task<bool> UpdateScenarioStep(RunScenarioStepModel model)
        {
            return await _cosmosDbService.UpdateItemAsync(runContainer, model.Run.Id, model);
        }
        #endregion

        // pre-requisties
        private async Task<UserActionResponse> PreRequistiesHandler(RunScenarioStepModel step, bool isPullDataRequired = false)
        {
            if (isPullDataRequired)
            {
                // TODO: @Lahiru - possible nullable value
                step = await GetScenarioStep(step.Scenario.Id, step.Seq);
            }
            // no dependancies should trigger next step
            if ((step.FDependancy.Count + step.VDependancy.Count) <= 0)
            {
                var interaction = CreateInteraction(
                    CoreRunRoles.System.ToString(),
                    "SYS",
                    CoreRunStepRenderTypes.View.ToString(),
                    "Required information obtained & processed",
                    step.Code,
                    string.Empty
                );
                await AddInteration(step.Run, step.Scenario.Seq, interaction);

                return new UserActionResponse
                {
                    Role = CoreRunRoles.System.ToString(),
                    Action = CoreRunStepActions.Next.ToString(),
                    NextStepId = step.NextStepId
                };
            }

            var response = new UserActionResponse();
            if (step.VDependancy.Count > 0)
            {
                UserActionResponse? userActionsForValueDependancies = await ProcessValueDependancies(step);
                if (userActionsForValueDependancies == null)
                {
                    response = await ProcessFunctionalDependancies(step);
                }
                else
                {
                    response = userActionsForValueDependancies;
                }
            }
            else
            {
                response = await ProcessFunctionalDependancies(step);
            }
            return response;
        }

        // value dependancies
        private async Task<UserActionResponse?> ProcessValueDependancies(RunScenarioStepModel step)
        {
            UserActionResponse? userAction = null;
            List<VDependancy> valueDependancies = step.VDependancy;

            VDependancy? valueDependancy = valueDependancies.Where(x => x.Filled == false).FirstOrDefault();
            if (valueDependancy == null) return userAction;

            userAction = await UserActionHandler(step, valueDependancy.Key, valueDependancy.Value);
            if (userAction == null) return null;

            userAction.Action = CoreRunStepActions.Input.ToString();
            return userAction;
        }
        private async Task<UserActionResponse?> UserActionHandler(RunScenarioStepModel step, string key, string value)
        {
            UserActionResponse? stepExecution = new UserActionResponse();
            switch (key)
            {
                case "REQ_SOURCE":
                    stepExecution = await UAH_REQ_SOURCE(step, value);
                    break;
                case "CODE_REPO_SOURCE":
                    stepExecution = await UAH_CODE_REPO_SOURCE(step, value);
                    break;
                case "API_SPEC_SOURCE":
                    stepExecution = await UAH_API_SPEC_SOURCE(step, value);
                    break;
                case "EXE_ADDRS_SOURCE":
                    stepExecution = await UAH_EXE_ADDRS_SOURCE(step, value);
                    break;
                default:
                    return null;
            }
            if (stepExecution == null) return null;

            stepExecution.InputKey = key;
            return stepExecution;
        }
        private async Task<UserActionResponse?> UAH_REQ_SOURCE(RunScenarioStepModel step, string value)
        {
            UserActionResponse? userAction = new UserActionResponse();
            string question = string.Empty;
            switch (value)
            {
                case "MNUL":
                    question = @"As a human, ask a direct question from me to provide the business requirement. 
                                Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.RichText.ToString();

                    break;
                case "JIRA":
                    question = @"As a human, ask a direct question from me to provide JIRA ticket numbers. If more than once JIRA ticket, 
                                ask to user comma separated values. Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();
                    break;
                case "CNFL":
                    question = @"As a human, ask a direct question from me to provide Confluence document link. 
                                Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();
                    break;
                default:
                    return null;
            }
            await ProcessQuestionInteraction(step, question);
            return userAction;
        }
        private async Task<UserActionResponse?> UAH_CODE_REPO_SOURCE(RunScenarioStepModel step, string value)
        {
            UserActionResponse? userAction = new UserActionResponse();
            string question = string.Empty;
            switch (value)
            {
                case "BTBK":
                    question = @"As a human, ask a direct question from me to provide public BitBucket clone URL. 
                                Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();

                    break;
                case "GTHB":
                    question = @"As a human, ask a direct question from me to provide public GitHub clone URL. 
                                Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();

                    break;
                case "LOCL":
                    question = @"As a human, ask a direct question from me to provide local system path to root folder of the. 
                                the code repository. Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();
                    break;
                default:
                    return null;
            }
            await ProcessQuestionInteraction(step, question);
            return userAction;
        }
        private async Task<UserActionResponse?> UAH_API_SPEC_SOURCE(RunScenarioStepModel step, string value)
        {
            UserActionResponse? userAction = new UserActionResponse();
            string question = string.Empty;
            switch (value)
            {
                case "XURL":
                    question = @"I am missing URL for API documentation. But I need to get only JSON or YAML formated documentation URLs only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();
                    break;
                case "MNUL":
                    question = @"I am missing API documentation. You should input that data into textarea. I need to get it as plain text.";
                    userAction.RenderType = CoreRunStepRenderTypes.RichText.ToString();
                    break;
                default:
                    return null;
            }
            await ProcessQuestionInteraction(step, question);
            return userAction;
        }
        private async Task<UserActionResponse?> UAH_EXE_ADDRS_SOURCE(RunScenarioStepModel step, string value)
        {
            UserActionResponse? userAction = new UserActionResponse();
            string question = string.Empty;
            switch (value)
            {
                case "XURL":
                    question = @"As a human, ask a direct question from me to provide live base URL without trailing slash (/) at the end.
                               Your response must have the question only";
                    userAction.RenderType = CoreRunStepRenderTypes.Text.ToString();
                    break;
                default:
                    return null;
            }
            await ProcessQuestionInteraction(step, question);
            return userAction;
        }
        private async Task ProcessQuestionInteraction(RunScenarioStepModel step, string question)
        {
            string llmReponse = _reqService.getHumanToneReponse(question);
            var interaction = CreateInteraction(
                CoreRunRoles.Assistant.ToString(),
                "SYS",
                CoreRunStepRenderTypes.View.ToString(),
                llmReponse,
                step.Code,
                string.Empty
            );
            await AddInteration(step.Run, step.Scenario.Seq, interaction);
        }

        // functional dependancies
        private async Task<UserActionResponse> ProcessFunctionalDependancies(RunScenarioStepModel step)
        {
            List<FDependancy> funcDependancies = step.FDependancy;
            UserActionResponse userAction = new UserActionResponse
            {
                Role = CoreRunRoles.System.ToString(),
                Action = CoreRunStepActions.Next.ToString(),
                NextStepId = step.NextStepId
            };

            if (step.FDependancy.Count <= 0)
            {
                string[] values = step.VDependancy.Select(x => x.Input).ToArray();
                userAction = await ProcessStep(step, values);
                return userAction;
            }

            FDependancy? funcDependancy = funcDependancies.Where(x => x.Retrieved == false).FirstOrDefault();
            if (funcDependancy == null) return userAction;

            userAction = await FunctionDataHandler(step);
            if (userAction == null) return userAction;
            return userAction;
        }
        private async Task<UserActionResponse> FunctionDataHandler(RunScenarioStepModel step)
        {
            List<string> dataValues = new List<string>();
            for (int i = 0; i < step.FDependancy.Count; i++)
            {
                string code = step.FDependancy[i].Code;
                string dataValue = await GetFunctionalDataValues(step, code);
                dataValues.Add(dataValue);

                step.FDependancy[i].Retrieved = true;
            }

            await _cosmosDbService.UpdateItemAsync(runContainer, step.Run.Id, step);

            UserActionResponse? userAction = await ProcessStep(step, dataValues.ToArray());
            if (userAction == null)
            {
                return new UserActionResponse
                {
                    Role = CoreRunRoles.System.ToString(),
                    Action = CoreRunStepActions.Next.ToString(),
                    NextStepId = step.NextStepId
                };
            }
            return userAction;
        }
        private async Task<string> GetFunctionalDataValues(RunScenarioStepModel step, string code)
        {
            string query = $"SELECT * FROM c WHERE c.run.id = '{step.Run.Id}' AND c.scenario.id = '{step.Scenario.Id}' AND c.code = '{code}' AND c.type = 'Step'";
            var refStepRaw = await _cosmosDbService.GetItemsAsync<RunScenarioStepModel>(runContainer, query);
            if (refStepRaw != null)
            {
                RunScenarioStepModel refStep = refStepRaw.First();
                return refStep.DataRef;
            }
            return string.Empty;
        }

        // process steps
        private async Task<UserActionResponse?> ProcessStep(RunScenarioStepModel step, params string[] values)
        {
            string process = step.Code;
            UserActionResponse userAction = new UserActionResponse();
            switch (process)
            {
                case "ENHC_REQ":
                    return await PS_ENHC_REQ(step, values);
                case "GNRT_BUSN_TPLAN":
                    return await PS_GNRT_BUSN_TPLAN(step, values);
                case "RTRV_REPO_MTDT":
                    return await PS_RTRV_REPO_MTDT(step, values);
                case "RTRV_API_DOC":
                    return await PS_RTRV_API_DOC(step, values);
                case "ENHC_API_DOC":
                    return await PS_ENHC_API_DOC(step, values);
                case "GNRT_TEST_EXE_PLAN":
                    return await PS_GNRT_TEST_EXE_PLAN(step, values);
                case "EXE_TEST":
                    return await PS_EXE_TEST(step, values);
                default:
                    return null;
            }
        }
        private async Task<UserActionResponse> PS_ENHC_REQ(RunScenarioStepModel step, params string[] values)
        {
            var enhancedReq = _reqService.Enhance(values[0]);
            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.View.ToString(),
                Action = CoreRunStepActions.Confirm.ToString(),
                RefData = enhancedReq,
                InputKey = step.Code
            };
            return userAction;
        }
        private async Task<UserActionResponse> PS_GNRT_BUSN_TPLAN(RunScenarioStepModel step, params string[] values)
        {
            var businessPlan = _reqService.GenerateBusinessTestPlan(values[0]);
            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.JSON.ToString(),
                SubRenderType = step.Code,
                Action = CoreRunStepActions.Confirm.ToString(),
                InputKey = step.Code,
                RefData = businessPlan
            };
            return userAction;
        }
        private async Task<UserActionResponse> PS_RTRV_REPO_MTDT(RunScenarioStepModel step, params string[] values)
        {
            var businessPlan = _repoService.GetRepoFileContent(values[0], "FILE", "DNET");
            string msg = "I have downloaded and retrieved metadata from repository successfully.";
            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.View.ToString(),
                Action = CoreRunStepActions.Complete.ToString(),
                InputKey = step.Code,
                RefData = msg,
                Content = businessPlan
            };

            // await UpdateDataRefForScenarioStep(step.Scenario.Id, step.Seq, businessPlan);
            return userAction;
        }
        private async Task<UserActionResponse> PS_RTRV_API_DOC(RunScenarioStepModel step, params string[] values)
        {
            var businessPlan = await _swaggerService.Get(values[0]);
            string msg = "We have downloaded api documentation.";
            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.View.ToString(),
                Action = CoreRunStepActions.Complete.ToString(),
                InputKey = step.Code,
                RefData = msg,
                Content = businessPlan
            };

            // await UpdateDataRefForScenarioStep(step.Scenario.Id, step.Seq, businessPlan);
            return userAction;
        }
        private async Task<UserActionResponse> PS_ENHC_API_DOC(RunScenarioStepModel step, params string[] values)
        {
            var businessPlan = _reqService.EnhanceSwaggerDocument(values[0], values[1]);

            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.Checkbox.ToString(),
                Action = CoreRunStepActions.Confirm.ToString(),
                InputKey = step.Code,
                RefData = businessPlan
            };

            return userAction;
        }
        private async Task<UserActionResponse> PS_GNRT_TEST_EXE_PLAN(RunScenarioStepModel step, params string[] values)
        {
            var businessPlan = _reqService.GenerateTestExecutionPlan(values[0], values[1], values[2]);
            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.JSON.ToString(),
                SubRenderType = step.Code,
                Action = CoreRunStepActions.Confirm.ToString(),
                InputKey = step.Code,
                RefData = businessPlan
            };
            return userAction;
        }
        private async Task<UserActionResponse> PS_EXE_TEST(RunScenarioStepModel step, params string[] values)
        {
            string baseUrl = step.VDependancy[0].Input;

            // tightly coupled
            BusinessTestExecutionService businessExection = new BusinessTestExecutionService();
            BusinessTestExecutionPlanModel plan = JsonConvert.DeserializeObject<BusinessTestExecutionPlanModel>(values[0]);

            var result = await businessExection.executeTestScenario(baseUrl, plan);
            UserActionResponse userAction = new UserActionResponse()
            {
                Role = CoreRunRoles.Assistant.ToString(),
                RenderType = CoreRunStepRenderTypes.JSON.ToString(),
                SubRenderType = step.Code,
                Action = CoreRunStepActions.Complete.ToString(),
                InputKey = step.Code,
                RefData = JsonConvert.SerializeObject(result)
            };
            return userAction;
        }

        public async Task<Response<List<RunInteractionResponse>>> GetRunScenarioInteractions(string runId, int scenarioSeq)
        {
            Response<List<RunInteractionResponse>> response = new Response<List<RunInteractionResponse>>();
            List<RunInteractionResponse> interactions = new List<RunInteractionResponse>();
            string scenarioId = GenerateScenarioId(runId, scenarioSeq);

            string query = $"SELECT * FROM c WHERE c.run.id = '{runId}' AND c.scenario.id = '{scenarioId}' AND c.type = 'Interaction'";
            var interactionsRaw = await _cosmosDbService.GetItemsAsync<ScenarioInteractionModel>(runContainer, query);
            var interaction = interactionsRaw.FirstOrDefault();

            if (interaction == null)
            {
                return new Response<List<RunInteractionResponse>>
                {
                    Data = new List<RunInteractionResponse>(),
                    IsSuccess = false,
                    Error = new ErrorResponse
                    {
                        Code = 404,
                        Message = "No interactions found"
                    }
                };
            }

            interactions = interaction.Interactions.Select(x => new RunInteractionResponse
            {
                Role = x.Role,
                Seq = x.Seq,
                Type = x.Type,
                SubType = x.SubType,
                Data = x.Data,
                Status = x.Status,
                Key = x.Key,

            }).ToList();
            response.Data = interactions;
            return response;
        }
    }

}
