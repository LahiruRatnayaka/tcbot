﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using sephira.app.Interfaces;
using sephira.app.Models.Common.Llm;
using sephira.app.Models.Common.ReqModule;
using System.Threading.Tasks;

namespace sephira.app.Services
{
    public class ReqService : IReqService
    {
        private readonly ILogger<ReqService> _logger;
        private readonly ILlmService _llmService;

        public ReqService(ILogger<ReqService> logger, ILlmService llmService)
        {
            _logger = logger;
            _llmService = llmService;
        }

        public string Enhance(string requirement)
        {
            LlmMessage systemPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a helpful business analyst."
            };

            LlmMessage userPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                //Content = $@"Understanding requirement is the most important aspect before plan for functional testing. However, all
                //            requirements are not well structured and well written. Requirement I am giving you may have grammar issues and might not be well-structured. 
                //            Please help me refine and enhance this requirement. Your goal is to enhance given requirement by correcting any grammatical errors, improve clarity, 
                //            and expand the requirement to ensure it covers all necessary details for generating functional test scenarios. In your response only include the Objective,
                //            Description, and Functional Requirements. DO NOT PROVIDE ANY OTHER CLARIFICATIONS OTHER THAN WHAT IS ASKED FOR 
                //            Original Requirement - {requirement}."

                Content = $@"Effective planning for functional testing hinges on a clear understanding of the project requirements. However, not all requirements 
                            are presented in a structured and well-articulated manner. The requirement provided may contain grammatical errors and lack proper structure.
                            **Objective:**
                                Refine and enhance the provided requirement by:
                                    1. Correcting grammatical errors.
                                    2. Improving clarity to ensure straightforward understanding.
                                    3. Expanding the requirement to cover all essential details necessary for generating functional test scenarios.
                            **Instructions:**
                                In your response, please include only the following sections:
                                    - Objective
                                    - Description
                                    - Functional Requirements (list of functional requirements)
                            Note: Do not provide any additional clarifications beyond what is specified.
                            **Original Requirement:**
                            {requirement}"
            };

            LlmConfig config = new LlmConfig
            {
                Temparature = 0.2F,
                enableJsonOutput = false
            };

            List<LlmMessage> messages = new List<LlmMessage>() { systemPrompt, userPrompt };
            string llmStringResponse = _llmService.Execute(config, messages);
            return llmStringResponse;
        }

        public string GenerateBusinessTestPlan(string enhancedRequrement)
        {
            LlmMessage systemPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a helpful business analyst. Your response should be in JSON format"
            };

            string jsonOutputFormat = @"{
                ""businessTests"": [
                    {
                        ""id"": ""Unique id to identify test scenarios that follows te-1 format"",
                        ""description"": ""simple functional description of the scenario for business users"",
                    }
                ]
            }";

            LlmMessage userPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                Content = $@"Given the below business requirement, generate all valid functional business test scenarios within the context of 
                            the business requirement. Each test scenario should be described in plain English without any technical terms
                            and must formatted to this format - ${jsonOutputFormat}.  Requirement - {enhancedRequrement}."
            };

            LlmConfig config = new LlmConfig
            {
                Temparature = 0.1F,
                enableJsonOutput = true
            };

            List<LlmMessage> messages = new List<LlmMessage>() { systemPrompt, userPrompt };
            string llmStringResponse = _llmService.Execute(config, messages);
            return llmStringResponse;
        }

        public string EnhanceSwaggerDocument(string existSpecification, string codeContent) 
        {
            LlmMessage systemPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a helpful tech lead"
            };

            LlmMessage userPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                //Content = $@"**This is the swagger documentation: {existSpecification} YOU MUST COMPARE THE SWAGGER 
                //    DOCUMENTATION WITH THE CONTROLLER CODE THAT I WILL PROVIDE YOU TO SEE IF IT IS MISSING ANY THINGS 
                //    IN THE DOCUMENTATION.YOU MUST RETURN THE OUTPUT IN THE SWAGGER DOCUMENTATION YAML FORMAT REMEMBER 
                //    YAML FORMAT AND ADD ON TO THE DOCUMENTATION IF NEEDED. You must remove the unnecessary information 
                //    and the page breaker. You must only give me the swagger documentation! Do not need to describe for 
                //    me what you have added i just want the pure documentation you must remember this. No page breaker such 
                //    as "" and do not tell me this is the swagger documentation!. I will also only want OPEN API v3.0.0 ONLY 
                //    YOU MUST REMEMBER YOU MUST ALSO REMEMBER TO CHECK THOROUGHLY TO SEE IF THE DOCUMENTATION COVERED ALL THE
                //    TEST SCENARIOS LIKE THE HTTP CODES 200, 400, 404 AND 500.I WILL PROVIDE YOU THE CONTROLLER CODE BELOW:{codeContent}"
                Content = $@"We are providing you the application code written for the application and exist swagger document. Your focus is to refer
                            code and enhance the existing swgger document in YAML format. Code Repo - {codeContent} and Existing Swagger - {existSpecification}"
            };

            LlmConfig config = new LlmConfig
            {
                Temparature = 0.1F,
                enableJsonOutput = false
            };

            List<LlmMessage> messages = new List<LlmMessage>() { systemPrompt, userPrompt };
            string llmStringResponse = _llmService.Execute(config, messages);
            return llmStringResponse;

        }

        public string GenerateTestExecutionPlan(string existSpecification, string testPlan, string codeRepo)
        {
            LlmMessage systemPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a helpful Test Engineer.Your output must be in JSON format"
            };

            string jsonOutputFormat = @"{
                ""executionPlans"": [
                    {
                        ""id"": ""Unique id to identify test that follows te-1 format"",
                        ""title"": ""Simple english title for the test scenario going to execute"",
                        ""path"": ""actual path to that should append to the base url. if query parameters required, fill them as well"",
                        ""method"": ""Http method to trigger"",
                        ""headers"": [ ""header values that should use to execute this endpoint for the given scenario as an array object with key and value pair""
                                {
                                 ""key"": ""Header key"",
                                 ""value"": ""Header value"",
                                }
                        ],
                        ""requestBody"": ""request body values required to trigger this endpoint for the given scenario in string format"",
                        ""expectedResponse"": { ""Expected response output according to the swagger and code for given scenario""
                            ""statusCode"": ""Expected status code"",
                            ""responseBody"": ""Expected response body""    
                        }
                    }
                ]
            }";

            LlmMessage userPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                //Content = $@"RULE 1 : for the specific swagger API provide, GENERATE functional test cases covering positive & negative scenarios.
                //            RULE 2 : remember functional_scenario cases in conjuction to swagger API provided, and GENERATE all MISSED functional test cases from RULE 1 ""
                //            RULE 3 : the output response should cover all inputs provide in Swagger API and functional_scenario    
                //            Your output response should follow below sample format""
                //            [{{
                //            ""scenarioId"": ""refer tsId from functional_scenario file provided""
                //            ""scenarioDesc"": ""refer tsDesc from functional_scenario file provided""
                //            ""testId"" : ""unique reference starting with TC-1""
                //            ""testDesc"" : ""name of the test case in plain english relating to scenarioDesc"",
                //            ""endPoint"": ""path of the endpoint without base. should start with / "",
                //            ""method"" : ""actual HTTP method ""
                //            ""header"" : ""header variables as an array object""
                //            ""requestBody"" : ""request object to include necessary variables to and values to trigger api call for given test scenario""
                //            ""responseOutput"" : ""generate response object suiting respective scenario & test data and sort by field names to compare ""
                //            ]

                //            functional_scenario : {TestPlan}
                //            swagger document : {existSpecification}"
                Content = $@"For the given swagger specification and business test plan, create a text execution plan in below given JOSN format, so I can trigger actual endpoint for testing
                            using generated data. If I were to do, I check swagger to understand how I can trigger endpoing, then read business test plan to understand which kind of scenarios
                            I have to trigger, then finally check code repo to understand varios scenarios I would test such if / switch conditions. . 
                            Swagger Specificaiton Document - {existSpecification}
                            Business Test Plan - {testPlan}
                            Code Repo - {codeRepo}

                            Final required output - {jsonOutputFormat}"
            };

            LlmConfig config = new LlmConfig
            {
                Temparature = 0.0F,
                enableJsonOutput = true
            };

            List<LlmMessage> messages = new List<LlmMessage>() { systemPrompt, userPrompt };
            string llmStringResponse = _llmService.Execute(config, messages);
            return llmStringResponse;

        }


        public string getHumanToneReponse(string ask) 
        {

            LlmMessage systemPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a helpful assistant."
            };

            LlmMessage userPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                Content = $@"Review the provided context carefully. Your task is to formulate one specific question that arises directly 
                            from this context. This question should aim to directly address a gap or need implied by the information given.
                            **Instructions:**
                                1. Read the context thoroughly.
                                2. Generate one question that directly relates to the content provided and ask in a human way.
                                3. You might need to provide additional information to make the question more specific.
                                4. Your question should seek a specific piece of information missing from the context without adding interpretations or assumptions.
                            **Context**
                            {ask}"
            };

            LlmConfig config = new LlmConfig
            {
                Temparature = 0.5F,
                enableJsonOutput = false
            };

            List <LlmMessage> messages = new List<LlmMessage>() { systemPrompt, userPrompt };
            string llmStringResponse = _llmService.Execute(config, messages);
            return llmStringResponse;
        }

        public string CompareTestExecutionResults(string executionPlan, string invokeResult)
        {
            LlmMessage systemPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a proffessional test engineer. Your response must be in JSON format"
            };

            string jsonOutputFormat = @"{
                ""result"": [
                    {
                        ""id"": ""Unique id as per test execution plan"",
                        ""title"": ""Simple english title as per test execution plan"",
                        ""response"": {
                                expected: ""expecting response from enpoint according to test scenario"",
                                actual: ""actual response from endpoint"",
                        },
                        ""endpoint"": ""endpoint as per the execution plan"",
                        ""result"": ""PASSED || FAILED"",
                        ""isPassed"": ""if PASSED then true"",
                        ""why"": [ 
                            ""list of facts and findings to categorise passed or failed scenario""
                        ],
                    }
                ]
            }";

            LlmMessage userPrompt = new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                Content = $@"I am providing expexted EXECUTION PLAN and ACTUAL RESPONSE from endpoints for test scenarios. Compare the actual response with the expected response 
                            in the execution plan.
                            **Instructions:**
                                1. Compare the actual response with the expected response (Please read NOTE).
                                2. Identify any discrepancies between the two (Please read NOTE).
                                3. Provide a detailed comparison of the actual and expected responses in given JSON FORMAT.  
                           
                            NOTE: Somtimes response not be exactly the same. For an eg. exepexted response timestamp could be differe from actual response timestamp. Likewise,
                            error messages may not be identical, but context will be there. Your focus should be compare context and understand that it could be a passed test case
                            or failed test case.
                            
                            **EXECUTION PLAN:**
                            {executionPlan}

                            **ACTUAL RESPONSE**
                            { invokeResult}
                            
                            **Expected JSON Output Format**
                            {jsonOutputFormat}"     

            };

            LlmConfig config = new LlmConfig
            {
                Temparature = 0.0F,
                enableJsonOutput = true
            };

            List<LlmMessage> messages = new List<LlmMessage>() { systemPrompt, userPrompt };
            string llmStringResponse = _llmService.Execute(config, messages);
            return llmStringResponse;
        }
    }
}

