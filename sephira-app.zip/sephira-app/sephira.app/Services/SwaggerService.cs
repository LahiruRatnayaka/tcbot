﻿using Microsoft.Extensions.Logging;
using sephira.app.Interfaces;
using sephira.app.Models.Common.Llm;

namespace sephira.app.Services
{
    public class SwaggerService : ISwaggerService
    {
        private readonly ILogger<SwaggerService> _logger;
        private readonly ILlmService _llmService;
        private readonly HttpRequestService _httpRequest;

        private LlmConfig llmConfig { get; set; }

        public SwaggerService(ILogger<SwaggerService> logger, ILlmService llmService, HttpRequestService httpRequest)
        {
            _logger = logger;
            _llmService = llmService;

            llmConfig = new LlmConfig
            {
                Temparature = 0.1F,
                enableJsonOutput = true
            };
            _httpRequest = httpRequest;
        }

        public async Task<string> Get(string url)
        {
            try
            {
                string reponse = await _httpRequest.ExecuteRequestAsync(url, HttpMethod.Get);
                return reponse;
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine($"Request error: {e.Message}");
                return null;
            }
        }

        public Task<string> Enhance(string repoCloneUrl, string swaggerUrl)
        {
            throw new NotImplementedException();
        }

        private LlmMessage systemPrompt()
        {
            return new LlmMessage
            {
                Role = Enums.LlmRole.SYSTEM,
                Content = "You are a helpful business analyst. Your output should be in JSON format"
            };
        }

        private LlmMessage userPrompt(params string[] values)
        {
            return new LlmMessage
            {
                Role = Enums.LlmRole.USER,
                Content = $@"I have a JIRA user story or task description that may have grammar issues and might not be well-structured. 
                                 Please help me refine and enhance this requirement. Your goal is to correct any grammatical errors, improve clarity, 
                                 and expand the requirement to ensure it covers all necessary details for generating business logic test scenarios.
                                 Here is the original user story/task description: {values[0]}. Please provide a refined version of the 
                                 requirement that is clear, grammatically correct, and detailed enough to be used for creating comprehensive business logic test scenarios. 
                                 JSON output format is {values[2]}"
            };
        }

        private string getJsonFormat()
        {
            return @"{ 
                ""objective"":""Objective of the user story or task description"",
                ""description"": ""Straight forward clear description of the user story or task"",
                ""functionalReq"" : [
                   ""list of functional requirements for given user story or task description""
                ]
            }";
        }

       
    }
}
