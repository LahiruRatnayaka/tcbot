﻿using Microsoft.Extensions.Logging;

// App
using sephira.app.Interfaces;
using sephira.app.Interfaces.databases;
using sephira.app.Models.Common;
using sephira.app.Models.Scenario.DataModels;
using sephira.app.Models.Scenario.ResponseModels;

namespace sephira.app.Services
{
    // Azure cosmos db related implementation
    public class _ScenarioService //: IScenarioService
    {
        private readonly ILogger<_ScenarioService> _logger;
        private readonly ICosmosDbService _cosmosDbService;

        private string scenarioContainer { get; set; } = "scenario";

        public _ScenarioService(ILogger<_ScenarioService> logger, ICosmosDbService cosmosDbService)
        {
            _logger = logger;
            _cosmosDbService = cosmosDbService;
        }

        public async Task<ScenarioModel> GetScenarioTemplate(string templateId)
        {

            string query = $"SELECT * FROM c WHERE c.id = '{templateId}'";
            var templateRaw = await _cosmosDbService.GetItemsAsync<ScenarioModel>(scenarioContainer, query);
            return templateRaw.FirstOrDefault();
        }

        public async Task<Response<List<ScenarioTemplateResponse>>> GetScenarioTemplates()
        {
            Response<List<ScenarioTemplateResponse>> response = new Response<List<ScenarioTemplateResponse>>();
            string query = $"SELECT * FROM c";
            var templatesRaw = await _cosmosDbService.GetItemsAsync<ScenarioModel>(scenarioContainer, query);

            if (templatesRaw == null)
            {
                response.IsSuccess = false;
                response.Error = new ErrorResponse()
                {
                    Code = 404,
                    Message = "Scenario templates not found"
                };
            }
            else
            {
                var teamplates = templatesRaw.ToList();
                response.Data = teamplates.GroupBy(x => x.Scenario.Category).Select(g => new ScenarioTemplateResponse
                {
                    Category = g.Select(y => y.Scenario.Name).FirstOrDefault(),
                    scenarios = g.ToList()
                }).ToList();
            }
            return response;
        }
    }
}
