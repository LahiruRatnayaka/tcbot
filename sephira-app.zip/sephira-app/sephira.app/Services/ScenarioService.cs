﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

// App
using sephira.app.Interfaces;
using sephira.app.Interfaces.databases;
using sephira.app.Models.Common;
using sephira.app.Models.Scenario.DataModels;
using sephira.app.Models.Scenario.ResponseModels;

namespace sephira.app.Services
{
    // Azure table storage related implementation
    public class ScenarioService : IScenarioService
    {
        private readonly ILogger<_ScenarioService> _logger;
        private readonly ITableStorageService _tableStorageService;

        public ScenarioService(ILogger<_ScenarioService> logger, ITableStorageService tableStorageService)
        {
            _logger = logger;
            _tableStorageService = tableStorageService;
        }

        public async Task<ScenarioModel> GetScenarioTemplate(string templateId)
        {
            var template = await _tableStorageService.GetItemAsync<TScenarioModel>("scenario", templateId, templateId);
            return JsonConvert.DeserializeObject<ScenarioModel>(template.Data);
        }

        public async Task<Response<List<ScenarioTemplateResponse>>> GetScenarioTemplates()
        {
            Response<List<ScenarioTemplateResponse>> response = new Response<List<ScenarioTemplateResponse>>();
            var templatesRaw = await _tableStorageService.GetItemsAsync<TScenarioModel>("scenario");

            if (templatesRaw == null || templatesRaw.Count <= 0)
            {
                response.IsSuccess = false;
                response.Error = new ErrorResponse()
                {
                    Code = 404,
                    Message = "Scenario templates not found"
                };
            }
            else {
                var templates = templatesRaw.Select(x=> JsonConvert.DeserializeObject<ScenarioModel>(x.Data)).ToList();
                response.Data = templates.GroupBy(x => x.Scenario.Category).Select(g => new ScenarioTemplateResponse
                { 
                    Category = g.Select(y=> y.Scenario.Name).FirstOrDefault(),
                    scenarios = g.ToList()
                }).ToList();
            }

            return response;
        }
    }
}
