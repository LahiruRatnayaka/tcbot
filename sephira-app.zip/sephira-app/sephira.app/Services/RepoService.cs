﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using sephira.app.Interfaces;
using sephira.app.Models.Common.CodeRepo;

namespace sephira.app.Services
{
    public class RepoService : IRepoService
    {

        private readonly ILogger<RepoService> _logger;
        private readonly IRepoConnector _repoConnector;

        public RepoService(ILogger<RepoService> logger, IRepoConnector repoConnector)
        {
            _logger = logger;
            _repoConnector = repoConnector;
        }

        public string GetRepoFileContent(string source, string type, string framework)
        {
            string localPath = GetLocalPath(source, type);
            string fileContent = ReadFileByFile(localPath, ExcludeExtentions(framework));
            bool success = DeleteRepo(localPath);
            return fileContent;
        }

        private string GetLocalPath(string source, string type)
        {
            string localPath = string.Empty;
            switch (type)
            {
                case "FILE":
                    localPath = $"C:/temp/sephira/local/{Guid.NewGuid().ToString("N")}";
                    CopyDirectory(source, localPath);
                    break;
                case "GTHB":
                    localPath = _repoConnector.CloneRepo(source);
                    break;
                default:
                    break;
            }
            return localPath;
        }

        private void CopyDirectory(string sourceDir, string destDir)
        {
            DirectoryInfo dir = new DirectoryInfo(sourceDir);
            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException($"Source directory does not exist or could not be found: {sourceDir}");
            }

            DirectoryInfo[] dirs = dir.GetDirectories();

            if (!Directory.Exists(destDir))
            {
                Directory.CreateDirectory(destDir);
            }

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string tempPath = Path.Combine(destDir, file.Name);
                file.CopyTo(tempPath, false);
            }

            // Copy subdirectories and their contents to new location.
            foreach (DirectoryInfo subdir in dirs)
            {
                string tempPath = Path.Combine(destDir, subdir.Name);
                CopyDirectory(subdir.FullName, tempPath);
            }
        }

        private string ReadFileByFile(string rootPath, List<string> excludedExtensions)
        {
            List<RepoFileContent> fileDataList = new List<RepoFileContent>();

            try
            {
                foreach (var filePath in Directory.GetFiles(rootPath, "*.*", SearchOption.AllDirectories))
                {
                    string extension = Path.GetExtension(filePath).ToLower();

                    if (excludedExtensions.Contains(extension))
                    {
                        continue;
                    }

                    string content = File.ReadAllText(filePath);
                    fileDataList.Add(new RepoFileContent
                    {
                        FileName = Path.GetFileName(filePath),
                        Content = content
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            return JsonConvert.SerializeObject(fileDataList);
        }

        private List<string> ExcludeExtentions(string framework)
        {
            List<string> extentions = new List<string> {
                ".md",
                ".yml",
                ".gitignore",
                ".json",
                ".txt"
            };

            switch (framework)
            {
                case "JAVA":
                    extentions.AddRange(new List<string> { });
                    break;
                case "DNET":
                    extentions.AddRange(new List<string> { ".sln", ".csproj" });
                    break;
                case "NODE":
                    extentions.AddRange(new List<string> {".test"});
                    break;
                default:
                    break;
            }
            return extentions;
        }

        private bool DeleteRepo(string path)
        {
            if (Directory.Exists(path))
            {
                Console.WriteLine($"Deleting folder {path}");
                Directory.Delete(path, true);
                return true;
            }
            return false;
        }
    }
}
