﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.app.Enums
{ 
    public enum LlmModel
    {
        GPT4O = 0,
        GPT4TURBO = 1,
        GPT3TURBO = 2,
        LLAMA3 = 3,
        LLAMA2 = 4,
        OPUS = 5,
        GEMINI = 6,
    }


    public enum LlmModelProvider
    {
        OAGPT = 0,
        LLAMA = 1,
        OPUS = 2,
        MIXTRAL = 3,
        MISTAL = 4
    }

    public enum LlmRole { 
        SYSTEM = 0,
        USER = 1,
        ASSISTANT = 2

    }
}
