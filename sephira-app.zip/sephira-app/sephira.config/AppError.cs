﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sephira.config
{
    public class AppError
    {
        public string BAD_REQUEST { get; private set; }
        public string INTERNAL_SERVER_ERROR { get; private set; }
        public string RATE_LIMIT { get; private set; }

    }
}
