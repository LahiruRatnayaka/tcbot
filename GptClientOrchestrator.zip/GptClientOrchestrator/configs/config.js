require('dotenv').config();

const APP_CONFIG = {
  CLIENT_APPS: process.env.CLIENT_APPS ?? [],
  DLP_MSG: '⚠️ WARNNING! It appears that your message contains confidential, personal or sensitive information. Please check and submit again. Thank you',
};

module.exports = {
  APP_CONFIG,
};
