require('dotenv').config();

const appConfig = {
  CorsAllow: process.env.CORS_WHITELIST.split(','),
  ProjectRed: {
    AzTableStrorage: {
      DbName: process.env.STORAGE_ACCOUNT_NAME,
      DbKey: process.env.STORAGE_ACCOUNT_KEY,
      DbPartitionKey: 'project-red',
    },
    AzBlobStorage: {
      ConnectionStr: process.env.STORAGE_ACCOUNT_CONNECTION_STRING,
      ContainerName: 'app-logs',
    },
    OpenAi: {
      Key: process.env.OPENAI_API_KEY,
    },

  },
};

module.exports = appConfig;
