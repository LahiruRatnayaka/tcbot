const { APP_CONFIG } = require('../configs/config');
const { DlpService } = require('../infra/dlp/dlp-service');
const { LlmService } = require('../infra/llm/az-openai-service');

const AppService = {
  dlp: async (promptArray, user, channel) => {
    const text = promptArray[promptArray.length - 1].content;
    const dlpService = new DlpService(user, text, channel);
    const dlpServiceResponse = await dlpService.run();
    return {
      isDetected: dlpServiceResponse.isDetected,
      message: dlpServiceResponse.isDetected ? APP_CONFIG.DLP_MSG : '',
      messageTimestamp: new Date().toISOString(),
    };
  },

  llm: async (promptArray, config) => {
    const llmService = new LlmService(config);
    const llmResponse = await llmService.run(promptArray);
    return llmResponse;
  },
};

module.exports.AppService = AppService;
