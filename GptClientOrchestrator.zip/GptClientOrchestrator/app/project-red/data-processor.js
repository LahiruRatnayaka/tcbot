const fs = require('fs');
const csv = require('csv-parser');

const cleanDataForStandardType = async (data) => {

};

function readFirstColumnFromCSV(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (data) => {
        results.push(data[Object.keys(data)[0]]);
      })
      .on('end', () => {
        resolve(results);
      })
      .on('error', (error) => {
        reject(error);
      });
  });
}


const cleanLogDataByType = async (data, type) => {
  let cleanedData = [];
  switch (type) {
    case 'standard':
      cleanedData = await cleanDataForStandardType(data);
      break;
    case 'mannual':
      cleanedData = [];
      break;
    default:
      cleanedData = [];
  }
  return cleanedData;
};

module.exports = {
  CleanLogDataByType: cleanLogDataByType,
};
