const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { OpenAIClient, AzureKeyCredential } = require('@azure/openai');
const { LlmService } = require('../../infra/llm/az-openai-service');
const { AzBlobStorage } = require('../../infra/database/azBlobStorage'); // Adjust the path as necessary
const appConfig = require('../../configs/app-config');
const { AzTableStorage } = require('../../infra/database/azTableStorage');

const db = new AzTableStorage(
  appConfig.ProjectRed.AzTableStrorage.DbName,
  appConfig.ProjectRed.AzTableStrorage.DbKey,
);

const LOG_ENTRY_TABLE = 'LogEntry';
const LOG_FILE_TABLE = 'LogFile';
const LOG_METADATA_TABLE = 'LogMetadata';
const LOG_PROJECT_TABLE = 'LogProject';
const LOG_REMEDIATION_TABLE = 'LogRemediation';

const AzBlobService = new AzBlobStorage(appConfig.ProjectRed.AzBlobStorage.ConnectionStr);

const AOAI_ENDPOINT = process.env.OPENAI_ENDPOINT;
const AOAI_APIKEY = process.env.OPENAI_API_KEY;
const client = new OpenAIClient(AOAI_ENDPOINT, new AzureKeyCredential(AOAI_APIKEY));
const deploymentId = 'gpt-4-1106-preview';

const prompts = new Map();
prompts.set('metadata', `You are a log pattern recognition model. Your task is to generate a general log pattern for a provided Log Input. The dataset consists of various log entries with different timestamp formats, log levels, application components, logger categories, log messages, and more. Your objective is to create a pattern that captures the common structure of these log entries in the following JSON format: { "pattern": "general log pattern" }. The generated pattern should be as versatile as possible to accommodate variations in log entries. DateTime format should align with ISO 8601 standards without changing given format. datetimeRegex value should JS REGEX pattern. Do not provide any explanation.
Example 1: log entries:
2024-02-01T09:00:00.123 INFO [main] com.example.app.StartApp - Application started successfully.
2024-02-01T09:01:15.456 WARN [http-nio-8080-exec-10] com.example.app.service.FeatureService - The feature toggle for 'betaFeature' is still enabled. Consider disabling it for production environments.
Example 1: output:
{"pattern": "[YYYY-MM-DDTHH:mm:ss.sss] [LEVEL] [[SOURCE]] [LOGGER] - [MESSAGE]", "levels": ["INFO", "WARN"], "criticalLevel": "WARN", datetimeRegex: "^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}"}
Example 2: log entries:
03/22 08:51:06 WARNING:.....mailslot_create: setsockopt(MCAST_ADD) failed - EDC8116I Address not available.
03/22 08:51:06 INFO   :....mailbox_register: mailbox allocated for rsvp-udp
Example 2: output:
{"pattern": "[MM/DD HH:mm:ss] [LEVEL]: [SOURCE]: [LOGGER] - [MESSAGE]", "levels": ["INFO", "WARNING"], "criticalLevel": "WARNING", "datetimeRegex":"^\d{2}\/\d{2} \d{2}:\d{2}:\d{2}"}
Example 3: log entries:
03-17 16:13:38.820  1702  8671 D PowerManagerService: ready=true,policy=3,wakefulness=1,wksummary=0x23,uasummary=0x1,bootcompleted=true,boostinprogress=false,waitmodeenable=false,mode=false,manual=38,auto=-1,adj=0.0userId=0
03-17 16:13:38.839  1702  2113 V WindowManager: Skipping AppWindowToken{df0798e token=Token{78af589 ActivityRecord{3b04890 u0 com.tencent.qt.qtl/com.tencent.video.player.activity.PlayerActivity t761}}} -- going to hide
Example 3: output:
{"pattern": "[MM-DD HH:mm:ss.SSS] [PID] [TID] [LEVEL] [LOGGER]: [MESSAGE]", "levels": ["D", "V"], "criticalLevel": "D", "datetimeRegex":"^\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}"}
Log Input: <<<LOG>>>
STRICT INSTRUCTIONS TO FOLLOW:
DO NOT PROVIDE ANY EXPLANATION.DO NOT PROVIDE ANY MARKDOWN syntax.`);

prompts.set('evaluator', `You are a log evaluator to organization standard shared later. Evaluate given log data against below standard rules and output PASSED. If not align with the rule output FAILED with step by step reasons. Make it a JOSN output as shared later in OUTPUT FORMAT:.
1. Use standard logging levels only [FATAL, ERROR, INFO, DEBUG, TRACE]
2. Use JSON format for logging
3. Consist and meaningful loggin messages
4. Structured logs
5. Contextual Information
6. Avoid sensitive inforamtion
7. Correlation IDs
8. Log at appropriate levels.

OUTPUT FORMAT: { \"evaluationResult\": [{
	"rule": "Rule from given rule set",
	"evaluation": Either PASSED or FAILED,
	"reason" : Reason for previous evaluation
}] }

Log Data to Evaluate: <<<LOG_ENTRY>>>

INSTRUCTIONS TO FOLLOW STRICTLY:
DO NOT PROVIDE ANY MARKDOWN syntax like \`\`\`json, should be a value JSON object starting with {.
DO NOT PROVIDE ANY EXPLANATION.
YOU OUTPUT MUST BE IN GIVEN OUTPUT FORMAT (JSON).
MUST PROVIDE OUTPUT IN GIVEN OUTPUT FORMAT`);

prompts.set('categorize', `You are a log pattern analyzer. Your task is to categorize log entries into three arrays based on the severity level and message content. Below are the three arrays and their explanations:
1. critical: Log entries that require immediate attention. Do not duplicate or repeat identical entries.
2. warning: Log entries that should be addressed as soon as possible to prevent imminent issues. Do not duplicate or repeat identical entries.
3. potential: Log entries that may become issues in the future. Do not duplicate or repeat identical entries.
Please exclude any log entry that does not fit the criteria mentioned above. Provide the final completion as an JSON object.
Final Completion Sample: { "critical":[], "warning":[], "potential":[] }. DO NOT ADD ANY MARKDOWN syntax.
Log Pattern: <<<LOG_PATTERN>>>
Log Input: <<<LOG>>>
STRICT INSTRUCTIONS TO FOLLOW:
DO NOT PROVIDE ANY EXPLANATION
DO NOT DUPLICATE THE SAME ENTRY IN DIFFERENT ARRAYS`);

prompts.set('remediate', `You are a log remidiation provider. Understand below log entry and provide primary reason and top three step by step guide for remidiation in below JSON output.

OUTPUT FORMAT: { \"primaryReason\": what is the primary potential cause for this error, \"stepByStepGuide" : array of object consit of title and description of step by step guide to remidiate the issue. }

Log Pattern: <<<LOG_PATTERN>>>
Log Input: <<<LOG_ENTRY>>>

INSTRUCTIONS TO FOLLOW STRICTLY:
DO NOT PROVIDE ANY MARKDOWN syntax.
MUST PROVIDE OUTPUT IN GIVEN OUTPUT FORMAT
MUST STOP AT THREE STEPS FOR REMIDIATION PLAN`);

const logs = new Map();

const queryFromLlm = async (promptKey, dataArray) => {
  console.log('query', JSON.stringify(dataArray));
  let content = String(prompts.get(promptKey));
  dataArray.forEach((data) => {
    content = content.replace(data.key, data.value);
  });

  const requestBody = [{ role: 'user', content }];

  console.log('cleint', JSON.stringify(client));
  const config = {
    LlmModel: 'gpt-4-1106-preview',
    Temparature: 0,
  };
  // azure
  const llmService = new LlmService(config);
  const llmResponse = await llmService.run(requestBody);
  const result = llmResponse;

  // localhost
  // const result = await client.getChatCompletions(deploymentId, requestBody, { temperature: 0.0 });

  console.log('result from LLM', result.choices[0].message);
  return JSON.parse(result.choices[0].message.content);
};

const logUploader = async (req, res) => {
  if (!req.files) {
    res.status(404).json({
      status: false,
      message: 'No file uploaded',
    });
  } else {
    const { file } = req.files;
    const fileId = uuidv4();
    const filename = fileId + path.extname(file.name);
    AzBlobService.uploadBuffer(
      appConfig.ProjectRed.AzBlobStorage.ContainerName,
      filename,
      file.data,
      file.size,
    )
      .then(() => res.status(201).json({
        status: true,
        message: 'File uploaded successfully',
        data: {
          id: fileId,
          file: filename,
          mimetype: file.mimetype,
          size: file.size,
        },
      }))
      .catch((error) => {
        res.status(404).json({
          status: false,
          message: `File upload failed: ${error.message}`,
          data: {},
        });
      });
  }
};

const splitContentByLines = async (filename, fileContent, linesPerChunk, splitter) => {
  const logEntriesSplits = [];
  const processIssues = [];
  let jsonLogs = [];
  try {
    const lines = fileContent.split(splitter);
		console.log('filecontent', fileContent);
    if (process.env.LOG_TYPE === 'standard') {
			console.log('inside');
      lines.forEach((line) => {
        let content = line.replace(/\\"|\\"/g, '\"').replace(/""/g, '"');
        content = content.substring(1, content.length - 1);
        try {
          jsonLogs.push(JSON.parse(content));
        } catch (error) {
          processIssues.push(content);
        }
      });
    } else {

      jsonLogs = lines;
    }

    // console.log('processIssues', processIssues);
     console.log('lines', jsonLogs);

    logs.set(filename, jsonLogs);
    for (let i = 0; i < jsonLogs.length; i += linesPerChunk) {
      const chunk = jsonLogs.slice(i, i + linesPerChunk);
      logEntriesSplits.push(chunk);
    }
  } catch (err) {
    console.error('Error chunking log entries:', err);
  }

  console.log('logEntriesSplits', logEntriesSplits.length);
  return logEntriesSplits;
};

const readFileContent = async (filename) => {
  let content = '';
  try {
    content = await AzBlobService.readFile(
      appConfig.ProjectRed.AzBlobStorage.ContainerName,
      filename,
    );
  } catch (err) {
    console.error('Error reading file:', err);
  }

  return content;
};

const logMetadataIdentifier = async (req, res) => {
  console.log('rlogMetadataIdentifier');
  const { filename } = req.body;
  const logContent = await readFileContent(filename);
  const logEntries = await splitContentByLines(filename, logContent, 100, '\n');
  const shortLog = (logEntries[0]).slice(0, 5);

	const logValue = process.env.LOG_TYPE === 'standard' ? JSON.stringify(shortLog) : shortLog.join('\n');
  const result = await queryFromLlm('metadata', [{ key: '<<<LOG>>>', value: logValue }]);
  console.log('pattern', result.pattern);

  res.status(200).json({
    status: true,
    message: 'Metadata identified successfully',
    data: {
      pattern: result.pattern,
      datetime: result.datetimeRegex,
      severity: {
        labels: result.levels,
        top: result.criticalLevel,
      },
      file: filename,

    },
  });
};

const logEvaluator = async (req, res) => {
  console.log('logEvaluator');
  const { filename } = req.body;
  const logContent = await readFileContent(filename);
  const logEntries = await splitContentByLines(filename, logContent, 100, '\n');
	const logValue = process.env.LOG_TYPE === 'standard' ? JSON.stringify(logEntries[0]) : logEntries[0].join('\n');
  const result = await queryFromLlm('evaluator', [{ key: '<<<LOG_ENTRY>>>', value: logValue }]);
  console.log('evaluator', result.evaluationResult);

  // need to check processing issues and if any error found JSON format evaluation should failed with structured logs

  res.status(200).json({
    status: true,
    message: 'Log entries evaluated successfully',
    data: {
      result: result.evaluationResult,
    },
  });
};

const removeTimestampFromLogEntry = (entry, pattern) => entry.replace(pattern, '');
// const re = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - /;

const logAnalyser = async (req, res) => {
  const {
    filename, pattern, level, regex,
  } = req.body;

  let logsArray = logs.get(filename);

  let FATAL_LOGS = [];
  let ERROR_LOGS = [];
  let WARN_LOGS = [];
  let INFO_LOGS = [];
  let DEBUG_LOGS = [];
  let TRACE_LOGS = [];

  if (process.env.LOG_TYPE === 'standard') {
    logsArray = logsArray.map((l) => ({
      ...l,
      loggerC: l.logger.replace(/\d+/g, '[number]'),
      msgC: l.msg.replace(/\d+/g, '[number]'),
    }));

    const seen = new Set();

    const uniqueLogs = logsArray.filter((obj) => {
      const fltr = `${obj.loggerC} - ${obj.msgC}`;
      if (!seen.has(fltr)) {
        seen.add(fltr);
        return true; // Keep this object, it's unique so far
      }
      // Object's newProperty1 value already encountered, filter it out
      return false;
    });

    console.log('uniqueLogs', uniqueLogs);
    FATAL_LOGS = uniqueLogs.filter((l) => l.level === 'FATAL');
    ERROR_LOGS = uniqueLogs.filter((l) => l.level === 'ERROR');
    WARN_LOGS = uniqueLogs.filter((l) => l.level === 'WARN');
    INFO_LOGS = uniqueLogs.filter((l) => l.level === 'INFO');
    DEBUG_LOGS = uniqueLogs.filter((l) => l.level === 'DEBUG');
    TRACE_LOGS = uniqueLogs.filter((l) => l.level === 'TRACE');
  } else {
 		console.log('log regex a', regex);
    const re = new RegExp(regex);
    console.log('log regex', re);
    logsArray = logsArray.map((mLog) => mLog.replace(re, '').replace(/\d+/g, '[number]'));
    const uniq = [...new Set(logsArray)];
    console.log('logsArray', logsArray.length);
    console.log('uniq', uniq.length);

    FATAL_LOGS = uniq.filter((l) => l.includes('FATAL'));
    ERROR_LOGS = uniq.filter((l) => l.includes('ERROR'));
    WARN_LOGS = uniq.filter((l) => l.includes('WARN'));
    INFO_LOGS = uniq.filter((l) => l.includes('INFO'));
    DEBUG_LOGS = uniq.filter((l) => l.includes('DEBUG'));
    TRACE_LOGS = uniq.filter((l) => l.includes('TRACE'));
  }

  res.status(200).json({
    status: true,
    message: 'Log file analysed successfully',
    data: {
			type: process.env.LOG_TYPE,
      logs: {
        fatal: FATAL_LOGS,
        error: ERROR_LOGS,
        warn: WARN_LOGS,
        info: INFO_LOGS,
        debug: DEBUG_LOGS,
        trace: TRACE_LOGS,
        unknown: [],
      },
      pattern,
      // file: filename,
      // summary: `Summary, critical: ${result.critical.length}, warning: ${result.warning.length}, potential: ${result.potential.length}`,
      // insights: result,
    },
  });
};

const logRemediator = async (req, res) => {
  console.log('logRemediator');
  const { logEntry, pattern } = req.body;
  const result = await queryFromLlm('remediate', [{ key: '<<<LOG_ENTRY>>>', value: logEntry }, { key: '<<<LOG_PATTERN>>>', value: pattern }]);
  console.log('remediate', result);

  res.status(200).json({
    status: true,
    message: 'Remediation provided successfully',
    data: {
      primaryReason: result.primaryReason,
      stepByStepGuide: result.stepByStepGuide,
    },
  });
};

const registerApplication = async (req, res) => {
  res.status(200).json('registeration');
};

const getApplications = async (req, res) => {
  const filter = '';
  const result = await db.listEntitiesAsync(LOG_PROJECT_TABLE, filter);
  console.log('project data', result);
  res.status(200).json(result);
};

module.exports = {
  LogUploader: logUploader,
  LogMetaDataIdentifier: logMetadataIdentifier,
  LogAnalyser: logAnalyser,
  LogRemediator: logRemediator,
  LogEvaluator: logEvaluator,
  LogApplication: {
    Register: registerApplication,
    Get: getApplications,
  },
};

// const log = {
//   name: '',
//   code: '',
//   original: '',
//   datetime: '',
//   occurance: [{
//     line: '',
//     lineNumber: 0,
//     date: '',
//     count: 0,
//   }],
//   primaryReason: '',
//   potentialReasons: [],
//   remidiation: {
//     highlevel: '',
//     stepbystep: [],
//   },
//   imidiateAction: '',
//   errorHierarchy: [],
// };
