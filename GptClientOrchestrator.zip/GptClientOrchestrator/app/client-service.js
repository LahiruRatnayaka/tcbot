const { APP_CONFIG } = require('../configs/config');

class ClientService {
  constructor(appId) {
    this.appId = String(appId);
  }

  isUnauthorizedClient = async () => {
    if (typeof this.appId === 'undefined') return true;
    const trimmedAppId = this.appId.trim();
    return (trimmedAppId === '' || !APP_CONFIG.CLIENT_APPS.includes(trimmedAppId));
  };

  config = async () => ({
    AppName: 'Navigator',
    AppId: this.appId,
    Developer: 'GWE-EFT',
    LlmModel: 'gpt-4',
    Temparature: 0,
  });
}

module.exports.ClientService = ClientService;
