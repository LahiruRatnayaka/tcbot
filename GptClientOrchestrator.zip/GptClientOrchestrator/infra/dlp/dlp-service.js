const { httpPostAsync } = require('../http/http-service');
/**
This class is used to call internally developed DLP service
to check if the user input has any sensitive or confidential
information and return the result to the caller
*/

class DlpService {
  constructor(user, prompt, channel) {
    this.user = user;
    this.prompt = prompt;
    this.channel = channel;
  }

  async run() {
    let validationResult;
    const url = process.env.DLP_SERVICE_URL;
    const payload = {
      user: this.user,
      text: this.prompt,
      channel: this.channel,
    };
    const headers = {
      'Content-Type': 'application/json',
    };
    console.log('BOT DlpService payload', JSON.stringify(payload));
    const dlpResponse = await httpPostAsync(url, payload, headers);
    console.log('BOT DlpService response', JSON.stringify(dlpResponse));
    if (dlpResponse.status === 'success') {
      validationResult = {
        isDetected: dlpResponse.data.isDetected,
        code: dlpResponse.data.identifier,
        match: dlpResponse.data.match === 'NA' ? '' : dlpResponse.data.match[0],
        message: dlpResponse.data.message,
      };
    }
    console.log('BOT DlpService validatoin', JSON.stringify(validationResult));
    return validationResult;
  }
}

module.exports.DlpService = DlpService;
