const { httpPostAsync } = require('../http/http-service');
const appConfig = require('../../configs/app-config');

async function gpt4(promptArray, clientConfig) {
  const url = process.env.GPT4_GATEWAY_URL;
  const payload = {
    messages: promptArray,
    temperature: clientConfig.Temparature,
  };
  const headers = {
    'Content-Type': 'application/json',
  };
  const openAiResponse = await httpPostAsync(url, payload, headers);
  return openAiResponse;
}

async function gpt4v1106Preview(promptArray, clientConfig) {
  const url = process.env.GPT4_1106_GATEWAY_URL;
  const payload = {
    messages: promptArray,
    temperature: clientConfig.Temparature,
  };
  const headers = {
    'Content-Type': 'application/json',
    // 'api-key': appConfig.ProjectRed.OpenAi.Key,
  };
  const openAiResponse = await httpPostAsync(url, payload, headers);
  return openAiResponse;
}

async function gpt35(promptArray, clientConfig) {
  const url = process.env.GPT35_GATEWAY_URL;
  const payload = {
    messages: promptArray,
    temperature: clientConfig.Temparature,
  };
  const headers = {
    'Content-Type': 'application/json',
  };
  const openAiResponse = await httpPostAsync(url, payload, headers);
  return openAiResponse;
}

class LlmService {
  constructor(config) {
    this.model = config.LlmModel;
    this.temperature = config.Temparature;
  }

  async run(promptArray) {
    let response = '';
    switch (this.model) {
      case 'gpt-4':
        response = await gpt4(promptArray, { Temparature: this.temperature });
        break;
      case 'gpt-35':
        response = await gpt35(promptArray, { Temparature: this.temperature });
        break;
      case 'gpt-4-1106-preview':
        response = await gpt4v1106Preview(promptArray, { Temparature: this.temperature });
        break;
      default:
    }
    return response;
  }
}

module.exports.LlmService = LlmService;
