// Azure Table Storage
const { TableClient, AzureNamedKeyCredential, odata } = require('@azure/data-tables');

class AzTableStorage {
  constructor(accoutName, accountKey) {
    this.accountName = accoutName;
    this.accountKey = accountKey;
    this.serviceUrl = `https://${this.accountName}.table.core.windows.net`;
    this.filter = odata;
  }

  connect(table) {
    return new TableClient(
      this.serviceUrl,
      table,
      new AzureNamedKeyCredential(this.accountName, this.accountKey),
    );
  }

  async createEntitiesAsync(table, payload) {
    const tableEntity = this.connect(table);
    await tableEntity.createEntity(payload);
  }

  async updateEntitiesAsync(table, payload) {
    const tableEntity = this.connect(table);
    await tableEntity.updateEntity(payload);
  }

  async updateEntitiesByReplaceAsync(table, payload) {
    const tableEntity = this.connect(table);
    await tableEntity.updateEntity(payload, 'Replace');
  }

  async listEntitiesAsync(table, filter) {
    const tableEntity = this.connect(table);
    const entities = tableEntity.listEntities({ queryOptions: { filter } });
    const result = [];
    for await (const entity of entities) {
      result.push(entity);
    }
    return result;
  }
}

module.exports.AzTableStorage = AzTableStorage;
