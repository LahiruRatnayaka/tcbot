// Azure Blob Storage
const { BlobServiceClient } = require('@azure/storage-blob');
const fs = require('fs');
const path = require('path');

class AzBlobStorage {
  constructor(connectionString) {
    this.blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);
  }

  async uploadFile(containerName, blobName, filePath) {
    try {
      const containerClient = this.blobServiceClient.getContainerClient(containerName);
      const blockBlobClient = containerClient.getBlockBlobClient(blobName);
      const uploadBlobResponse = await blockBlobClient.uploadFile(filePath);
      console.log(`Upload block blob ${blobName} successfully`, uploadBlobResponse.requestId);
      return uploadBlobResponse.requestId;
    } catch (error) {
      console.error('Error uploading file: ', error.message);
      throw error;
    }
  }

  async uploadBuffer(containerName, blobName, buffer, bufferSize) {
    try {
      const containerClient = this.blobServiceClient.getContainerClient(containerName);
      const blockBlobClient = containerClient.getBlockBlobClient(blobName);
      const uploadBlobResponse = await blockBlobClient.uploadData(buffer, {
        blockSize: bufferSize, // You can set this to a value that works well for your application
      });
      console.log(`Upload block blob ${blobName} successfully`, uploadBlobResponse.requestId);
      return uploadBlobResponse.requestId;
    } catch (error) {
      console.error('Error uploading buffer: ', error.message);
      throw error;
    }
  }

  async downloadFile(containerName, blobName, downloadFilePath) {
    try {
      const containerClient = this.blobServiceClient.getContainerClient(containerName);
      const blobClient = containerClient.getBlobClient(blobName);
      const downloadBlockBlobResponse = await blobClient.downloadToFile(downloadFilePath);
      console.log(`Downloaded blob ${blobName} to ${downloadFilePath}`);
      return downloadFilePath;
    } catch (error) {
      console.error('Error downloading file: ', error.message);
      throw error;
    }
  }

  async readFile(containerName, blobName) {
    try {
      const containerClient = this.blobServiceClient.getContainerClient(containerName);
      const blobClient = containerClient.getBlobClient(blobName);
      const downloadBlockBlobResponse = await blobClient.download();
		//	console.log('readable content', downloadBlockBlobResponse.readableStreamBody);
      const downloadedContent = await this.streamToString(downloadBlockBlobResponse.readableStreamBody); // eslint-disable-line
      console.log(`Read content for blob ${blobName}`);
      return downloadedContent;
    } catch (error) {
      console.error('Error reading file: ', error.message);
      throw error;
    }
  }

  // Helper function to read a stream into a string
  async streamToString(readableStream) { // eslint-disable-line
    return new Promise((resolve, reject) => {
      const chunks = [];
      readableStream.on('data', (data) => {
        chunks.push(data.toString());
      });
      readableStream.on('end', () => {
        resolve(chunks.join(''));
      });
      readableStream.on('error', reject);
    });
  }
}

module.exports.AzBlobStorage = AzBlobStorage;
