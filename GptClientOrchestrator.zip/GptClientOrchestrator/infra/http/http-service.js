const axios = require('axios');
const { json } = require('body-parser');

function httpPostAsync(url, payload, headers) {
  console.log('url', url);
  console.log('payload', payload);
  console.log('headers', headers);
  return new Promise((resolve, reject) => {
    axios.post(url, payload, headers)
      .then((response) => {
        resolve(response.data);
      }).catch((error) => {
        reject(error);
      });
  });
}

function httpGetAsync(url, payload, headers) {
  return new Promise((resolve, reject) => {
    axios.get(url, payload, headers)
      .then((response) => {
        resolve(response.data);
      }).catch((error) => {
        reject(error);
      });
  });
}

module.exports = {
  httpPostAsync,
  httpGetAsync,
};
