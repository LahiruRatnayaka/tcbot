export default function LogPrompts() {
// empty
}
