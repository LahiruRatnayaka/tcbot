require('dotenv').config();
const express = require('express');
const fileupload = require('express-fileupload');
const cors = require('cors');
const bodyParser = require('body-parser');
const appConfig = require('./configs/app-config');

// PROJECT RED SERVICES
const {
  LogUploader,
  LogMetaDataIdentifier,
  LogAnalyser,
  LogRemediator,
	LogEvaluator,
  LogApplication,
} = require('./app/project-red/service');

const { AppService } = require('./app/app-service');
const { ClientService } = require('./app/client-service');

const server = express();
server.use(bodyParser.json());
server.use(
  fileupload({
    createParentPath: true,
  }),
);
// server.use(cors());
server.use(
  bodyParser.urlencoded({
    extended: true,
  }),
);

// cors
const whitelist = appConfig.CorsAllow;
const corsOptions = {
  origin(origin, callback) {
    console.log('origin', origin, whitelist);
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
};

server.listen(process.env.port || process.env.PORT || 3978, () => {
  console.log(`Server started, ${server.name} listening to ${process.env.PORT || 3978}`);
});

// GET: Test Applicaiton
server.get('/api/v1/notify', cors(corsOptions), async (req, res) => {
  res.json({ status: 'service is running successfully.' });
});

// POST: Messages from Microsoft Teams channel
server.post('/api/client/v1/chat/completion', cors(corsOptions), async (req, res) => {
  const clientId = req.get('X-Gpt-Client-Id');
  const { user, prompt, channel } = req.body;

  const client = new ClientService(clientId);
  console.log('API CLIENT', clientId);
  const app = AppService;

  const response = {
    status: 'success',
    data: {},
    error: {},
    dlp: {},
  };

  try {
    // check client validation
    if (await client.isUnauthorizedClient()) {
      console.log('API CLIENT VALIDATION', clientId);
      response.status = 'error';
      response.error = {
        code: 'GPT-401',
        message: 'Unauthorized client',
      };
      res.json(response);
      return;
    }

    // check dlp validation
    const dlpResponse = await app.dlp(prompt, user, channel);
    console.log('API DLP', dlpResponse);
    if (dlpResponse.isDetected) {
      response.status = 'dlp';
      response.dlp = {
        code: 'DLP-CODE',
        message: dlpResponse.message,
      };
      res.json(response);
      return;
    }

    // get llm response
    const llmResonse = await app.llm(prompt, await client.config());
    console.log('API LLM', llmResonse);
    const data = {
      id: llmResonse.id,
      object: llmResonse.object,
      service: 'ocbc-gpt-pilot',
      created: llmResonse.created,
      model: llmResonse.model,
      choices: [llmResonse.choices[0].message],
    };

    response.data = data;
    res.json(response);
  } catch (err) {
    console.log('API ERR', err);
    response.status = 'error';
    response.error = {
      code: 'GPT-500',
      message: err,
    };
    res.json(response);
  }
});

/**
 * APPLICATION PROJECT RED START
 * Project RED (Reactive Log Detection) is a PoC application
 * to analyse log files and generate valuable insights using
 * GPT models.
 *
 * Lead Engineer: Lahiru Ratnayaka
 * Colloboration: Emerging & Foundation Technologies and Order Management Team
 * Timeline: 2024-JAN/FEB
 */
server.post('/api/project-red/v1/upload', cors(corsOptions), async (req, res) => {
  try {
    await LogUploader(req, res);
  } catch (err) {
    res.status(500).send(err);
  }
});

server.post('/api/project-red/v1/evaluate', cors(corsOptions), async (req, res) => {
  try {
    await LogEvaluator(req, res);
  } catch (err) {
    res.status(500).send(err);
  }
});

server.post('/api/project-red/v1/identify', cors(corsOptions), async (req, res) => {
  try {
    await LogMetaDataIdentifier(req, res);
  } catch (err) {
    res.status(500).send(err);
  }
});

server.post('/api/project-red/v1/analyse', cors(corsOptions), async (req, res) => {
  try {
    await LogAnalyser(req, res);
  } catch (err) {
    res.status(500).send(err);
  }
});

server.post('/api/project-red/v1/remediate', cors(corsOptions), async (req, res) => {
  try {
    await LogRemediator(req, res);
  } catch (err) {
    res.status(500).send(err);
  }
});

server.get('/api/project-red/v1/applications/get', cors(corsOptions), async (req, res) => {
  try {
    await LogApplication.Get(req, res);
  } catch (err) {
    res.status(200).send(err);
  }
});

server.get('/api/project-red/v1/applications/get:id', cors(corsOptions), async (req, res) => {
  // try {
  //   await LogApplication(req, res);
  // } catch (err) {
  //   res.status(200).send(err);
  // }
});

server.post('/api/project-red/v1/applications/post', cors(corsOptions), async (req, res) => {
  try {
    await LogApplication.Register(req, res);
  } catch (err) {
    res.status(500).send(err);
  }
});
